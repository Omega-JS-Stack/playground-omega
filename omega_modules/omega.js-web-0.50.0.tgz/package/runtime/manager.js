/**
 * The frontend Manager handed to every global/page module as
 * `{ manager, options }` — UJM's src/index.js Manager minus the webpack
 * module loading (build-time layering picks the winning page module now).
 * Wraps the @omega.js/client singleton and carries the browser-side mode helpers.
 *
 * Environment comes from `window.OMEGA_BUILD_JSON.config.environment`, baked
 * into the page by core/foot.html at build time (#894, set by the engine from
 * the build's `environment` option).
 */
import omega from '@omega.js/client';

class Manager {
  constructor() {
    this.omega = omega;
  }

  getEnvironment() {
    const config = (typeof window !== 'undefined' && window.OMEGA_BUILD_JSON?.config) || {};
    return config.environment || 'development';
  }

  isDevelopment() {
    return this.getEnvironment() === 'development';
  }

  isProduction() {
    return this.getEnvironment() === 'production';
  }

  isTesting() {
    return this.getEnvironment() === 'testing';
  }
}

export { Manager };
