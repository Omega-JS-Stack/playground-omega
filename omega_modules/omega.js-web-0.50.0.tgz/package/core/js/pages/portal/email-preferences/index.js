/**
 * Email Preferences Page JavaScript
 */

// Libraries
import { FormManager } from '@omega.js/client/modules/form-manager.js';
import fetch from 'wonderful-fetch';
import omega from '@omega.js/client';
import { WAKEUP_ROUTE } from '@omega.js/client/modules/request.js';
import { event } from '__main_assets__/js/libs/analytics.js';

// Module
export default () => {
  return new Promise(async function (resolve) {
    // Warm the backend the moment the page loads: an unsubscribe arrives from
    // an email, clicks once, and that click is a POST to
    // `/omega/marketing/email-preferences`. Fire-and-forget and
    // unauthenticated — the backend answers a wakeup before it loads a route
    // ([#644](https://github.com/Omega-JS-Stack/omega/issues/644)).
    omega.request(WAKEUP_ROUTE, { wakeup: true });

    // Initialize when DOM is ready
    await omega.dom().ready();

    setupForm();

    // Resolve after initialization
    return resolve();
  });
};

// Decode a base64-encoded URL parameter
function decodeParam(encoded) {
  if (!encoded) {
    return '';
  }

  try {
    return atob(decodeURIComponent(encoded));
  } catch (e) {
    return '';
  }
}

// Mask an email address: show first 2 and last char of local part, first 2 chars of domain
// e.g. "ian.wiedenman+test-unsub@gmail.com" → "ia***************b@gm***.com"
function maskEmail(email) {
  const [local, domain] = email.split('@');

  if (!local || !domain) {
    return '***@***.***';
  }

  const domainParts = domain.split('.');
  const domainName = domainParts.slice(0, -1).join('.');
  const tld = domainParts.slice(-1)[0];

  const maskedLocal = local.length <= 3
    ? local[0] + '*'.repeat(local.length - 1)
    : local.slice(0, 2) + '*'.repeat(local.length - 3) + local.slice(-1);

  const maskedDomain = domainName.length <= 2
    ? domainName
    : domainName.slice(0, 2) + '*'.repeat(domainName.length - 2);

  return `${maskedLocal}@${maskedDomain}.${tld}`;
}

// Setup form handling
function setupForm() {
  const url = new URL(window.location.href);

  // Parse and decode URL parameters
  const email = decodeParam(url.searchParams.get('email'));
  const asmId = decodeParam(url.searchParams.get('asmId'));
  const templateId = decodeParam(url.searchParams.get('templateId'));
  const sig = url.searchParams.get('sig') || '';

  // DOM elements
  const $description = document.getElementById('email-preferences-description');
  const $error = document.getElementById('email-preferences-error');
  const $errorMessage = document.getElementById('email-preferences-error-message');
  const $content = document.getElementById('email-preferences-content');
  const $address = document.getElementById('email-preferences-address');
  const $submit = document.getElementById('email-preferences-submit');
  const $infoUnsubscribe = document.getElementById('email-preferences-info-unsubscribe');
  const $infoResubscribe = document.getElementById('email-preferences-info-resubscribe');
  const $actionButtons = document.querySelectorAll('[data-action]');

  // Validate required parameters
  if (!email || !asmId || !sig) {
    $description.textContent = 'Something went wrong.';
    $errorMessage.textContent = 'This link is invalid or expired. Please try clicking the link in your email again.';
    $error.hidden = false;
    return;
  }

  // Populate UI
  $description.textContent = 'Confirm your email address to update your email preferences.';
  $address.textContent = maskEmail(email);
  $content.hidden = false;

  // Track current action
  let currentAction = 'unsubscribe';

  // Action toggle buttons
  $actionButtons.forEach($btn => {
    $btn.addEventListener('click', () => {
      currentAction = $btn.dataset.action;

      // Update active state
      $actionButtons.forEach($b => $b.classList.remove('active'));
      $btn.classList.add('active');

      // Toggle info messages
      $infoUnsubscribe.hidden = currentAction !== 'unsubscribe';
      $infoResubscribe.hidden = currentAction !== 'resubscribe';

      // Update submit button — one adaptive voice; the icon + label carry
      // the action (the old danger/success repaint fought the theme)
      $submit.className = 'btn btn-adaptive w-100 mb-4';
      if (currentAction === 'unsubscribe') {
        $submit.querySelector('.button-text').innerHTML = `<i class="fa-solid fa-bell-slash me-2"></i>Unsubscribe`;
      } else {
        $submit.querySelector('.button-text').innerHTML = `<i class="fa-solid fa-bell me-2"></i>Resubscribe`;
      }
    });
  });

  // Initialize FormManager
  const formManager = new FormManager('#email-preferences-form', {
    autoReady: false,
    allowResubmit: false,
  });

  // Custom validation: confirm email matches
  formManager.on('validation', ({ data, setError }) => {
    if (data.email_confirm.toLowerCase().trim() !== email.toLowerCase().trim()) {
      setError('email_confirm', 'Email does not match. Please enter the email address this was sent to.');
    }
  });

  // Submit handler
  formManager.on('submit', async ({ data }) => {
    const action = currentAction;

    trackEmailPreference(action);

    try {
      await fetch(`${omega.getApiUrl()}/omega/marketing/email-preferences`, {
        method: 'POST',
        response: 'json',
        body: {
          email: email,
          asmId: asmId,
          action: action,
          sig: sig,
        },
        timeout: 30000,
      });

      if (action === 'unsubscribe') {
        formManager.showSuccess('You have been successfully unsubscribed. You will no longer receive these emails.');
      } else {
        formManager.showSuccess('You have been successfully resubscribed. You will start receiving these emails again.');
      }
    } catch (error) {
      omega.sentry().captureException(new Error('Email preferences error', { cause: error }));
      throw new Error('An error occurred while processing your request. Please try again.');
    }
  });

  // Ready
  formManager.ready();
}

// Tracking. The two outcomes are two catalog entries, not one name built from
// a variable: a canonical name is a literal a reader can grep for.
function trackEmailPreference(action) {
  event(action === 'unsubscribe' ? 'marketing_email_unsubscribe' : 'marketing_email_subscribe', {
    content_type: 'email_preferences',
  });
}
