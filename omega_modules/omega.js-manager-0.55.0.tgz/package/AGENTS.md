@docs/omega.md
