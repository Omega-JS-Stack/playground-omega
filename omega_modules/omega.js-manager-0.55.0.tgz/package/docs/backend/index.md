# OMEGA Backend (@omega.js/backend)

> **Note for contributors and Claude:** This file is the guide for `@omega.js/backend` — identity, top-level conventions, and a map to the deep references. It lives in the monorepo's `docs/` tree and is loaded on demand (the omega Claude plugin's hooks inject it by context; the map, `docs/omega.md`, is what every AGENTS.md imports, and only the manager ships the docs). The **meat** (per-subsystem APIs, behavior tables, recipes) lives in the `docs/backend/<topic>.md` files beside this guide. When extending or adding content, write it in the matching `docs/backend/*.md` file and cross-link from here — do NOT inline it. If a topic doesn't have a doc yet, create one.

> **Mirrored structure:** the four framework guides (`docs/web/index.md`, `docs/backend/index.md`, `docs/extension/index.md`, and `docs/desktop/index.md`) mirror each other: shared sections (Supply-Chain Security, Development Workflow, File Conventions, Doc-update parity, etc.) appear in the **same order at the same position** across all four. When adding a section that applies to multiple frameworks, insert it in the same spot in all of them.

## Identity

OMEGA Backend (@omega.js/backend) is a comprehensive framework for building modern Firebase Cloud Functions backends, the backend of the OMEGA family beside @omega.js/web, @omega.js/desktop and @omega.js/extension. Its main export is ONE ready-made instance, `omega`: `omega.initialize(options)` boots it and wires the built-in functions (`omega_api`, the auth and Firestore triggers, the cron schedules), the request pipeline, the `Context` every handler receives, the services (User, Usage, Analytics, Settings, Utilities, Metadata, Storage, Email, AI), payment provider integrations (Stripe / PayPal / Chargebee / Coinbase Commerce), Firestore-trigger pipelines, marketing campaign automation, an MCP server, and a CLI for emulator/deploy/logs/auth/Firestore operations.

**This repository** is the @omega.js/backend library itself. **Consumer projects** are src-first Firebase apps: `require('@omega.js/backend')` in `src/index.js`, with optional `src/routes/`, `src/schemas/`, and `src/hooks/` for custom endpoints; `omega build` stages everything into `dist/` (the tree `firebase.json` points at). Config is loaded via `@omega.js/config` (shared sections top-level, backend settings under `targets.backend`; brand-monorepo hierarchy supported — brand targets carry NO config file of their own).

## Recommended skills

- **`omega:backend`** — the router skill from the omega Claude plugin. The inject hook loads it automatically in any project with `@omega.js/backend` (root or `functions/`, and inside `packages/backend` here); it points back to this guide + `docs/` (the SSOT).
- **`js:patterns`** — JavaScript/Node.js conventions: file structure, JSDoc, defensive coding (`?.` usage), template literals, `package.json` conventions. Auto-loads when creating new `.js` files or touching JS module structure.

## Quick Start

### For Consuming Projects

1. `@omega.js/backend` is the backend target's runtime dependency (onboard declares it in `targets/<name>/package.json`, and the staged `dist/package.json` derives from that manifest); `npm install` at the brand root installs it
2. Run any verb: there is no bootstrap command ([#675](https://github.com/Omega-JS-Stack/omega/issues/675)). Every verb calls `ensureTarget()` first (`src/cli/utils/ensure-target.js`), which scaffolds `.firebaserc`, `firebase.json`, `src/index.js`, `engines.node`, `firestore.rules`, `database.rules.json`, states the manifest's `license` once when it states none (`UNLICENSED`, npm's word for closed-source commercial code, seeded the same way by all four frameworks and carried into the staged `dist/package.json`; an authored license is never overwritten, [#884](https://github.com/Omega-JS-Stack/omega/issues/884)), syncs the standard `package.json` scripts to the framework's defaults: one `"<verb>": "omega <verb>"` per verb the backend owns, derived from the verb table (`@omega.js/devkit/verb-scripts`, [#985](https://github.com/Omega-JS-Stack/omega/issues/985)), plus `start` (`omega dev`) from the `dev` row, and no declared `projectScripts` (framework-owned keys, rewritten on every run; customize through hook points, not by editing them, [#689](https://github.com/Omega-JS-Stack/omega/issues/689); each spells the verb BARE: `omega serve`, never `npx omega`, since npm already puts `node_modules/.bin` on the path inside a script, [#748](https://github.com/Omega-JS-Stack/omega/issues/748)), plus the defaults tree via the shared devkit engine: CHANGELOG.md, docs/, test/, `.gitignore` (`.gitignore` live-syncs its `Default Values` section, which is COMPLETELY framework-managed: a line the framework retires or rewrites leaves your file on the next run, so anything you own goes under `Custom Values`, [#926](https://github.com/Omega-JS-Stack/omega/issues/926)). A standalone project root also gets devkit's one `AGENTS.md`, the same file a brand root carries ([agent-docs](../shared/agent-docs.md)). It is idempotent and silent when nothing changes, and it writes no `.env`: that file is yours (see [The env cascade](#the-env-cascade--678)). `npx omega test --target=<name>` adds the target CHECKS on top (config validation, Firestore index provisioning)
3. `npx omega emulator --target=<name>`: start Firebase emulators (auth/firestore/functions/database/storage). Every boot first reaps the machine's orphaned emulator-family processes left by earlier runs (parent gone, this user, a strict command match: hub, functions worker, functions discovery server, emulator jar, puppeteer chrome) whatever project they named, and logs one line naming what it removed ([#781](https://github.com/Omega-JS-Stack/omega/issues/781)). This is also a **prerequisite of the brand's frontend targets**: the website's dev server auto-connects Auth/Firestore to these emulators with no live-Firebase opt-out, and the brand root's bare `npx omega dev` boots them beside it ([docs/web/index.md](../web/index.md))
4. `serve`: local serve with Stripe webhook forwarding (if `STRIPE_SECRET_KEY` is set). At a brand root `serve` is `omega dev`'s alias, so a brand boots its backend with `npx omega dev --target=<name>`, which runs the target's `start` script: `omega dev`, the backend's dev loop, is the full emulator suite `omega emulator` boots. `serve` itself runs in a standalone project
5. `npx omega test --target=<name>`: runs the project's test suites against an emulator through the target's own `npm test`, which is `omega test` with the scope after `--` (bare consumer runs never include the framework corpus; the framework self-test context flips the default). Positional target(s) select which test FILES run, by source + path (multiple space-separated targets compose):
   - `npx omega test --target=<name>`: the project's suites
   - `npx omega test --target=<name> email/transactional`: bare path (no prefix): project tests matched by path (relative to `test/`)
   - `npx omega test --target=<name> full:` / `npx omega test --target=<name> full:email`: BOTH sources, the explicit way to include the framework suite
   - `npx omega test --target=<name> mgr:` / `npx omega test --target=<name> backend:`: ONLY framework tests (`mgr:` is the universal cross-framework alias for the manager's own tests; `backend:` is the equivalent @omega.js/backend-specific alias)
   - `npx omega test --target=<name> mgr:email/templates` / `npx omega test --target=<name> backend:email/templates`: only framework tests matching a path
   - `npx omega test --target=<name> project:`: ONLY project tests (all of them)
   - `npx omega test --target=<name> project:routes/custom`: only consumer project tests matching a path
   - `npx omega test --target=<name> backend:rules project:routes`: multiple targets compose (runs both selections)
   - Pass `--extended` (or prefix `TEST_EXTENDED_MODE=true`) for tests that hit real external APIs (SendGrid, OpenAI, etc.). `--extended` is the CLI shorthand for the shared, unprefixed `TEST_EXTENDED_MODE` env var standardized across all four frameworks; @omega.js/backend propagates it to BOTH the runner subprocess and the live emulator. See [docs/backend/test-framework.md](test-framework.md#extended-mode-test_extended_mode).
   - Pass `--lane=<name>` for an OPT-IN lane: suites that exist only for a real external service, unreachable by any other run, each behind a gate that prints one skip line rather than failing. Today: `--lane=stripe-live`, which creates test-mode fixtures, forwards REAL Stripe webhooks into the emulator with `stripe listen`, and opens only for an `sk_test_` secret resolved through the ONE env reader (put it in the brand's `.env.testing` overlay). See [docs/backend/test-framework.md](test-framework.md#opt-in-lanes---lane).
6. `npx omega deploy --target=<name>`: deploy Cloud Functions to Firebase
7. `npx omega logs:read --target=<name>` / `npx omega logs:tail --target=<name>`: Cloud Function logs from Google Cloud Logging

> **Important:** every `npx omega ...` command runs at the brand root, `--target=<name>` naming the backend target; inside `targets/<name>/` (its `functions/` and `dist/` included) the verbs the backend owns run in place (`npm test`, `npx omega emulator`, `npx omega test framework:`) while a brand-wide verb refuses and prints the root form ([docs/manager/brand.md](../manager/brand.md) § Verbs). A standalone project is its own root and drops the picker. `dist/` is staged output: never edit it.

### For Framework Development (This Repository)

> **🚫 NEVER use `npx omega ...` from the framework repo.** `npx omega` is for CONSUMER projects (where the bin is linked in the target's `node_modules/.bin/`). From the framework repo, use `npm test`, `npm run prepare`, etc. — the `scripts` in `package.json` call the local `bin/` directly.

1. `npm install` — install @omega.js/backend's own deps
2. `npm run prepare` — build once: copies `src/` → `dist/` via prepare-package
3. `npm run prepare:watch` — watch mode
4. `npm test`: run framework tests via the bundled fixture project (equivalent to `node bin/omega test`). Accepts the same target syntax: `npm test -- mgr:helpers/content/blog-auto-publisher`. Bare = the fast `boot/` smoke; the FULL framework suite passes against the fixture too: `npm test -- backend:` (the fixture carries corpus-parity payment config and boot-syncs the canonical rules; see [docs/backend/test-boot-layer.md](test-boot-layer.md))
5. Test in the **designated test consumer**: `brands/playground-omega/targets/backend`, the backend target of the standing in-repo test brand, is @omega.js/backend's consumer for validating framework changes end-to-end ([docs/shared/brands.md](../shared/brands.md)). Its `@omega.js/backend` spec is a `file:` path into this monorepo, so it runs this working tree's build with no linking step (the root `npm start` keeps that build current). Run its verbs at the brand root: `cd brands/playground-omega && npx omega test --target=backend`.

## Architecture

@omega.js/backend's runtime is ONE instance of the `Omega` class (`src/omega/index.js`): `initialize()` initializes Firebase Admin, builds the process services, and wires the built-in functions into `omega.functions`. Every request, event and cron job runs with a `Context` (`ctx`). Supports **two deployment modes**: Firebase Functions (`projectType: 'firebase'`) or Custom Server (`projectType: 'custom'`). See [docs/backend/architecture.md](architecture.md) for the full overview of the instance, dual-mode support, the derived `config.resolved.*` values consumer code reads (`config.resolved.github`, the brand's SOURCE repo `<brand.id>-omega`, which is the repo the CMS routes commit content to), and the services.

For the directory layout of both the @omega.js/backend library and consumer projects, see [docs/backend/directory-structure.md](directory-structure.md).

**The package's public surface is its `exports` map**, spelled the way the sibling frameworks spell theirs: `.` (the instance), `./test` (the public test API: `defineCases` for a consumer's case files, `const { defineCases } = require('@omega.js/backend/test')`), `./config` (the vendored `@omega.js/config`), `./lib/email-constants` and `./lib/mcp-utils` (the marketing catalog the manager reads, the consumer MCP loader), `./cli`, `./ensure-target` and `./migrate` (the doors the dispatcher and the brand root reach), and `./package.json`. A path the map does not name is refused (`ERR_PACKAGE_PATH_NOT_EXPORTED`); `bin/omega`, `templates/` and the framework's own `test/` stay files on disk, reached by path. Pinned by `test/boot/exports.test.js`.

### The consumer entry

```js
// src/index.js (CommonJS, synchronous: Firebase reads the exports at module load)
const omega = require('@omega.js/backend');

omega.initialize({ /* options */ });

module.exports = omega.functions;
```

The package's main export IS the instance; a consumer never writes `new` (the class is exported by name, `Omega`, for tests). `initialize(options)` is synchronous and returns the instance. `omega.functions` is the Cloud Functions map the framework filled; a function of the brand's own joins it before the export line ([routes.md](routes.md#functions-entry-point-srcindexjs)). Every option is optional:

| Option | Default | What it does |
|---|---|---|
| `projectType` | `targets.backend.projectType` | `'firebase'` or `'custom'`; the config decides, an explicit option wins |
| `resourceZone` | `'us-central1'` | The functions region |
| `sentry` | `true` | Error reporting through `@omega.js/monitoring`; `reportErrorsInDev` (default `false`) extends it to development |
| `firebaseConfig` | `FIREBASE_CONFIG` | The Firebase project the instance reads as `omega.project` |
| `serviceAccountPath` | `'service-account.json'` | The key a LOCAL script initializes Firebase Admin with (a managed runtime uses its own identity) |
| `checkNodeVersion` | `true` | In development, exit on a Node.js older than the manifest's `engines.node` (`false` only logs it) |
| `uniqueAppName` | none | The Firebase Admin app name, and the namespace of `omega.storage()` |
| `cwd` / `projectPackageDirectory` | `process.cwd()` / `cwd` | The functions directory, and where the consumer's `package.json` is read |
| `logSavePath` | `false` | A file the logger also writes to |
| `express.bodyParser` | `{ json: { limit: '100kb' }, urlencoded: { limit: '100kb', extended: true } }` | The custom server's body limits |
| `identity` | `true` | Wire the blocking `omega_authBeforeCreate` and `omega_authBeforeSignIn` triggers |
| `useFirebaseLogger` | `true` | In production, route `console` to Cloud Logging's structured logger |

The test runner passes nothing: `OMEGA_TEST_RUNNER` alone turns off the Firebase init, the function wiring, the custom server and Sentry.

### The instance (`omega`)

| Member | What it is |
|---|---|
| `config` | The composed `config/omega.json5`, with `config.resolved` (the derived values) |
| `env` | The env reader (below) |
| `logger` | A `Context` with no request: `omega.logger.log()`, `.warn()`, `.error()` |
| `version`, `cwd`, `project`, `package`, `options` | The framework version, the functions directory, the Firebase project (`projectId`, `resourceZone`, the URLs), the consumer's `package.json`, the resolved options |
| `firebase.admin`, `firebase.app`, `firebase.functions` | The Admin SDK, the initialized app, and the `firebase-functions/v1` SDK (`null` in custom mode) |
| `functions` | The Cloud Functions map the consumer exports |
| `server` | `{ app, server }` once a custom-server backend listens, else `null` |
| `handlers` | The pre/post hook bag, keyed by function name ([routes.md](routes.md#new-event-handler)) |
| `utilities`, `email`, `ai`, `storage(options)` | The process services, built once |
| `sentry` | The capture handle, `null` when reporting is off |
| `routes.run(name, { req, res }, options)` | Run a request through the pipeline as the named consumer route, from the consumer's own function |
| `events.run(name, payload)` | Run an event handler through the dispatcher (a relative name loads `<cwd>/events/<name>.js`) |
| `require(name)` | Resolve a dependency from the framework's own module context |
| `getEnvironment()`, `isDevelopment()`, `isProduction()`, `isTesting()` | The environment ([environment-detection.md](environment-detection.md)) |
| `getFunctionsUrl()`, `getApiUrl()`, `getWebsiteUrl()`, `getParentUrl()`, `getParentApiUrl()`, `isParent()` | The URL helpers, local in development and testing |

### `Context` (`ctx`)

One class for routes, events and cron (`src/omega/context.js`, its methods mixed in from `src/omega/context/`). One instance wraps one request, or one trigger invocation; `ctx.request` is `null` outside HTTP.

- **Fields**: `omega`, `req`, `res`, `id`, `tag`, `meta` (`{ startTime, name, environment, type }`), `tmpdir`, `data` (the validated input), and `request.{method,url,path,headers,body,query,data,geolocation,client,type,referrer,multipart}`.
- **Request services**, each built on first read: `ctx.user` (a `User` from `@omega.js/account`, signed out until `authenticate()` resolves the caller), `ctx.usage`, `ctx.analytics`, `ctx.email`, `ctx.ai`, and `ctx.metadata(metadata, document)`.
- **Methods**: `log warn error info debug notice critical emergency` and `setLogPrefix()`; `respond(payload, options)`, `redirect(url, options)`, `report(error, options)`; `authenticate(options)`; `parseMultipart(options)`; and `getEnvironment()` with the three checks, forwarded from the instance.

### The handler contracts

Every handler receives ONE object and destructures what it needs; everything in it is also on `ctx`:

```js
module.exports = async ({ ctx, omega, user, data, usage, analytics }) => { };       // routes
module.exports = async ({ ctx, omega, user, context, change, snapshot }) => { };    // auth and Firestore events
module.exports = async ({ ctx, omega, context }) => { };                            // cron jobs
```

A route answers through `ctx.respond()`. An event's `user` is the trigger's Auth `UserRecord`; a route's `user` is the caller's `User`. Recipes: [routes.md](routes.md).

### Services

`src/omega/services/` holds one class per service, one shape: `class X { constructor(owner) }`. A process service takes `omega` and is built once in `initialize()`; a request service takes `ctx` and is built on first read. A route never constructs one: it reads it off `ctx` or `omega`.

| Service | Owner | Reached as |
|---|---|---|
| `utilities.js` | `omega` | `omega.utilities`: collection and user iteration, the cached document read, `randomId()`, `slugify()`, `sanitize()`, `trim()` |
| `storage.js` | `omega` | `omega.storage({ name })`: a named local JSON store |
| `user.js` | `omega` | Installs the id generators on `@omega.js/account`'s `User`, so every `new User(doc)` mints real ids |
| `usage.js` | `ctx` | `ctx.usage`: the counted-feature gate ([usage-rate-limiting.md](usage-rate-limiting.md)) |
| `analytics.js` | `ctx` | `ctx.analytics`: GA4 events as the caller |
| `metadata.js` | `ctx` | `ctx.metadata()`: a document's metadata block |
| `settings.js` | `ctx` | The pipeline's validation step into `ctx.data` |

Email and AI live in `src/omega/libraries/email/` and `libraries/ai/`: `omega.email` and `omega.ai` log through the instance's logger, `ctx.email` and `ctx.ai` through the request.

### The request pipeline

Every request (the deployed `omega_api`, a consumer's own function through `omega.routes.run()`, the custom server) passes ONE ordered list of named steps in `src/omega/pipeline.js`: the route guard, the dev-only guard, the options, multipart, the request log, wakeup, the handler load, authenticate, usage, the user log, analytics, validation, trim, sanitize, the handler. Each step returns true when it ended the request. The options a consumer's `omega.routes.run()` passes (`authenticate`, `setupUsage`, `setupAnalytics`, `validate`, `includeUnknown`, `sanitize`, `schema`, `parseMultipart`, `routesDir`, `schemasDir`) are in [routes.md](routes.md#the-pipeline-options).

### The one schema system

A route's schema file exports a function of the request, `({ user, body, query, path, method, headers, geolocation })`, and returns a plain field declaration (`{ limit: { type: 'number', default: 10, max: 100 } }`). ONE adapter, `src/omega/helpers/schema.js`, turns it into a zod schema and validates with it; a split on the plan, the request or the input is ordinary code in the function. Defaults coerce and never reject. The vocabulary, the full example and the split kinds: [schemas.md](schemas.md).

### File map (`src/omega/`)

| Path | What it holds |
|---|---|
| `index.js` | The `Omega` class and the one instance: `initialize()`, the function wiring, the environment and URL helpers |
| `context.js`, `context/` | The `Context` class; its logging, response, authentication, parsing and client-info concerns |
| `pipeline.js` | The request pipeline's steps |
| `router.js` | `omega_api`'s dispatch: the MCP endpoint, else the framework's route (a consumer route rides its own function) |
| `events.js` | The event dispatcher behind every trigger and `omega.events.run()` |
| `cron.js` | The cron runner: the framework's jobs, then the consumer's `hooks/cron/<schedule>/` |
| `server.js` | Custom-server mode: the same routes on an express app |
| `services/` | The services above |
| `helpers/` | Pure helpers: the schema adapter, log redaction, the resolved config, safe compare |
| `libraries/` | Email, AI, payment, analytics, content, the env reader, and the provider libraries |
| `routes/`, `schemas/` | The framework's built-in routes and their schemas |
| `events/` | The framework's auth, Firestore and cron handlers |

### The wakeup short-circuit

Any request carrying `wakeup` in its data (query or body) is answered `{ wakeup: true }` by the request pipeline's `wakeup` step and goes no further ([pipeline.js](../../../backend/src/omega/pipeline.js)). The check runs BEFORE the route module is loaded and before the caller is authenticated, so the request costs one cold start and nothing else. There is no dedicated ping route and none is needed: every route is the same warm-up at the same price.

The frontend half is `omega.request(WAKEUP_ROUTE, { wakeup: true })` ([docs/client/index.md](../client/index.md), which lists every page and surface that fires it) — web, desktop and extension all warm the function ahead of the first user action that needs it ([#637](https://github.com/Omega-JS-Stack/omega/issues/637), [#644](https://github.com/Omega-JS-Stack/omega/issues/644)).

### Custom-server mode — `projectType: 'custom'` ([#584](https://github.com/Omega-JS-Stack/omega/issues/584))

**The brand's config is the switch**, not an init flag: `targets.backend.projectType` in `config/omega.json5` (`'firebase'`, the default, or `'custom'`), resolved by `initialize()` off the loaded config, so a consumer's `src/index.js` stays the same two lines in both modes. An explicit `initialize({ projectType })` wins for a caller that means to override it.

Custom mode is the SAME backend: the same routes, the same schemas, the same request pipeline, the same services, the same `.env`, served by the Express app on `process.env.PORT` (the framework's routes mount under `/omega/`, a consumer's at their own path, the URL shape Firebase mode serves) (`src/omega/server.js`, exposed as `omega.server`) for a container host (Render and the like) instead of exported as Cloud Functions. `firebase-functions` is not even loaded (`omega.firebase.functions` is `null`); `firebase-admin` still is, so Firestore, Auth and the rest of the Admin SDK work exactly as before.

What it takes away is the **Firebase lane**, and `src/cli/utils/project-type.js` is the ONE home of that list. Each verb refuses loudly, names the mode, names the lane that replaces it, and exits 1 — a refusal that read green would look like a deploy that happened:

| Verb | In custom mode |
|---|---|
| `omega deploy` | REFUSED — a custom backend publishes through its host; put that command in this target's `deploy` script, which the brand-root `omega deploy` runs |
| `omega dev` | REFUSED: there are no Cloud Functions to emulate; this target's own `start` script boots the server on `PORT`, and the brand-root `omega dev` runs it |
| `omega serve` | REFUSED — `npm start` boots the server on `PORT` |
| `omega emulator` | REFUSED — there are no Cloud Functions to emulate |
| `omega test` | Runs, with no emulator: it skips the emulator boot, the hosting health check and the account setup, then runs the discovered suites. A unit case that reads `firebase.json` or a rules file skips when the file is absent; any other suite that needs the emulator fails on its own assertion |
| the verbs' scaffold | Runs, minus the Firebase-only half ([#614](https://github.com/Omega-JS-Stack/omega/issues/614)) and minus the brand-owned scripts ([#689](https://github.com/Omega-JS-Stack/omega/issues/689)) — see below |
| `omega build`, everything else | Unchanged — a custom backend stages `src/` → `dist/` like any other |

**The scaffold writes no Firebase-only artifact** in custom mode ([#614](https://github.com/Omega-JS-Stack/omega/issues/614)): no `firebase.json` (deploy targets + emulator config), no `firestore.rules`, no `database.rules.json`, no `storage.rules`, no `firestore.indexes.json` — and no compiled `dist/firestore.rules`, which nothing in this mode deploys. The checks that maintain those files (every firebase.json check, the rules and index seeds, the live index sync) come off the run with them; the same `project-type.js` table names both lists. Everything else is the identical scaffold — the config, `.firebaserc`, the service account, the project directories, the defaults. Skipping is not deleting: a custom project that authored a `firebase.json` (or rules) of its own keeps it exactly as written, migrations included.

**The script sync turns per KEY** ([#689](https://github.com/Omega-JS-Stack/omega/issues/689)): the scripts running a verb this mode refuses (`start`, which runs `omega dev`, and `deploy`) are the BRAND's, never written and never scaffolded (no placeholder to delete), while `test` and every other script stay framework-owned like anywhere else. `CUSTOM_OWNED_SCRIPTS` in `project-type.js` is the one home of that list, DERIVED from `FIREBASE_ONLY_VERBS` (every script whose command runs one of those verbs), and both writers read it: this framework's scaffold, and the manager's workspace walk through `@omega.js/backend/ensure-target`.

The brand-root side of it — how the manager deploys, tests and boots a custom backend — is in [deploys.md](../shared/deploys.md) and [manager/index.md](../manager/index.md).

### The env reader (`libraries/env.js`) — #581

Every framework read of a brand-supplied env key goes through ONE reader; nothing under `src/omega/` touches `process.env.<KEY>` directly except the runtime's own vars (`FIREBASE_CONFIG`, `FUNCTIONS_EMULATOR`, `GCLOUD_PROJECT`, the `OMEGA_*_PORT` map, the test-mode switches).

- `env.get('KEY')` — the resolved value, empty reading as absent. A key the env schema does not declare **throws** (`UnknownEnvKeyError`): a typo used to resolve to `undefined` forever.
- `env.has('KEY')` — the switch every optional provider gates on.
- `env.require('KEY')` — value or `MissingEnvKeyError` (code 500) naming the key and the fix.
- `env.assertRequired('backend')`: the **boot guard**, run by `initialize()`: every required key of the schema, validated in ONE pass, with ONE error listing everything missing. A brand's backend refuses to boot in **every environment**, development included: the keys are one `npx omega manage` away, and booting without them only moves the crash to a customer's first order email ([#569](https://github.com/Omega-JS-Stack/omega/issues/569)). The single advisory lane is a process with no consumer `config/omega.json5`, the framework booting itself, where there is no brand for a manage run to have minted keys into; it warns and continues. The self-test fixture is brand-shaped, so `omega test` seeds its required keys from the fixture's own config values (`ensureFixtureEnv`), the same way manage mints a real brand's.

- `env.getEnvironment()`: the runtime environment, and exactly what `omega.getEnvironment()` returns. It is `@omega.js/config`'s ONE environment module re-exported ([#817](https://github.com/Omega-JS-Stack/omega/issues/817), the contract in full: [docs/shared/config.md](../shared/config.md)), the same four functions @omega.js/desktop, @omega.js/extension and @omega.js/web answer with, so the three names the `.env.<environment>` overlay files are spelled with (#586) and the three the runtime answers are ONE vocabulary. It is reachable here because the provider libraries below hold no instance handle. It reads ONE input, `OMEGA_ENVIRONMENT`, which `initialize()` sets ONCE right after the `.env` cascade loads, from `envEnvironment()`, the ambient answer, whose rules are unchanged: an emulator run or an explicit `ENVIRONMENT=development` is development, `OMEGA_TEST_MODE` is testing, and "no signal" resolves to **production**, because a deployed Cloud Function has no `FUNCTIONS_EMULATOR` and often no `ENVIRONMENT`. Nothing re-sniffs a raw signal at read time, and a process whose lane never named one throws by name. The bare `env.environment()` alias is gone: the name is the one every surface uses.

**One key, every environment** ([#586](https://github.com/Omega-JS-Stack/omega/issues/586)) — the reader never decides WHICH name to read. A key whose value must differ between a local run and a deployed one is supplied by the brand's `.env.<environment>` overlay under the SAME name, and the cascade has already resolved it before anything reaches `env.get()`. So a brand puts its `sk_test_…` in `.env.development` and its live key in `.env`, and `Stripe.init()` still calls `env.get('STRIPE_SECRET_KEY')`. There is no `<KEY>_DEV` twin and no live-shape guard: every key is equal and its value is trusted.

**Which key the emulator charges is the BRAND's answer, not a guard's** ([#586](https://github.com/Omega-JS-Stack/omega/issues/586)). The backend uses whatever key the env chain resolves for the running environment, whatever that key turns out to be, and it never inspects a value to decide. Putting the TEST key in `.env.development` is what keeps a live key out of the local emulator, and it is the brand's own opt-in: onboarding writes only the base `.env`, so a brand with no overlay runs its local emulator on whatever `.env` holds. Since the `_DEV` twins were removed nothing else stands between a live key and a local run, so a brand that puts a live key in `.env` and writes no overlay CAN charge a real card from the emulator. Write the overlay.

The key inventory (owner, targets, generated-or-third-party, required, description) lives in `@omega.js/config`'s env schema — the same list the manager mints from and the composer below delivers from: [docs/shared/config.md](../shared/config.md).

### The env cascade — #678

`dist/.env` is **generated output**, composed on every verb that stages ([#678](https://github.com/Omega-JS-Stack/omega/issues/678)). Nobody has to run a manage first for a brand-root key to reach the artifact.

- **Two human files, one machine file.** The brand root's `.env` is the one file humans and the manager edit. A target's own `.env` is OPTIONAL — a per-key override you write by hand. No machine writes either target `.env` or brand `.env` values into a target. `dist/.env` is the machine's, regenerated from scratch on every stage.
- **The layers, weakest first**: company `.env` ← brand `.env` ← target `.env`, resolved through `@omega.js/config`'s `resolveEnvChain` (the same walk the runtime cascade uses), each layer overlaid by its own `.env.<environment>` file (#586). Files only — never the shell, so a build produces the same artifact under any terminal. An empty value never claims a key.
- **The schema is the only filter.** A key rides down from the company/brand layers when an `ENV_SCHEMA` entry claims it (by name OR by pattern — the `CONNECTIONS_<PROVIDER>_CLIENT_ID`/`_SECRET` family composes), names `backend` in its `targets`, and sits in a file group. A desktop signing key stays out of the functions upload. The target layer passes through UNFILTERED: placing a key in the target's own `.env` is the targeting.
- **`deliverAs` renames on delivery**: the brand's `GOOGLE_ANALYTICS_SECRET_BACKEND` arrives as `GOOGLE_ANALYTICS_SECRET`, the one name the runtime reads.
- **The dev server restages** on a change to the target, brand-root, or company `.env` — the watcher resolves all three through the chain (`envWatchInputs`), never a hard-coded path.
- **Each lane stages for ONE environment** (#586): `omega deploy` composes base + `.env.production`, the emulator base + `.env.development`, `omega test` base + `.env.testing` — `stageFunctions({ environment })`, and the stage WATCH keeps the boot's own environment, so a hot reload can never swap the artifact's overlay mid-run. No other environment's file ever rides the upload.
- Delivered key NAMES and the layer each came from are logged; a value never is.
- **A value Firebase would decode differently is refused at staging**, naming the key: Firebase's own `.env` reader decodes backslash codes dotenv leaves alone. The rule: [docs/shared/config.md](../shared/config.md).

### Test framework

`npm test` (`npx omega test --target=<name>` at the brand root) is the one entry: it runs every suite the runner discovers under the project's `test/` (scope `framework:` or `full:` to include the framework's own) against a **real Firebase emulator** (real Firestore/Auth, never mocked). Suites are organized by concern (`test/unit/`, `test/routes/`, `test/events/`, `test/rules/`, …) rather than runtime layers. See [docs/backend/test-framework.md](test-framework.md).

**A plain run reaches nothing past this machine.** Before the suites, the runner installs its connect trap (`src/test/connect-trap.js`) in its own process: a TCP connect or DNS lookup to any host but this machine (`127.0.0.1`, `::1`, `localhost`, and the unspecified `0.0.0.0` and `::` a bind probe resolves) throws `CONNECT_TRAP`, so a suite that requires the framework tree can never reach live Firebase with whatever `.env` and `.omega/secrets/` carry, while the emulator on loopback stays reachable. `--extended` and `--lane=` runs exist to reach real services, so the runner installs no trap there.

**The framework suite runs from a consumer too** ([#720](https://github.com/Omega-JS-Stack/omega/issues/720)): `npx omega test --target=<name> mgr:` at the brand root works on a locally linked brand AND on a plain npm install, because the package ships `test/` as raw source (a `files` entry beside `dist/`). That is why every case file requires the framework through `../../dist/…` rather than `../../src/…`, and `@omega.js/devkit` / `@omega.js/config` / `@omega.js/account` through `../../dist/vendor/…`: `src/` never ships and those packages never publish, so the shipped copies are the only ones an install can reach. In the monorepo `dist/` is the prepare output the root watch keeps fresh, edit `src/`, and the suite reads it once the watch has copied it. `test/boot/suite-portability.test.js` audits every require and package-relative path literal in `test/` against the published `files` list, so a case file that reaches back into `src/` fails at home instead of in a consumer.

The unit suites ship as skeletons in `test/unit/` the brand OWNS and edits, runner case files like every other suite: `registration.test.js` (index.js boots the installed framework; every dispatched route resolves and its imports load), `rules-posture.test.js` (every Firestore/Storage path the brand opens is declared in the suite, so adding a rule is deliberate), `socket-free.test.js` (the trap is armed, and refuses). They pass on a freshly scaffolded target and need no emulator, so they run on a custom-server backend too.

### Test coverage

Every feature ships with tests at EVERY surface it exposes: logic (`test/routes/`/`test/events/` handler suites against the real emulator), wiring (route round-trips over `http.as(...)`: registration, auth gates, schema validation; this IS @omega.js/backend's end-to-end), and rules (Firestore security-rules suites when rules change). @omega.js/backend has no UI layer: a feature's UI coverage lives in the consuming frontend (web, extension, desktop). Skip a surface ONLY when the feature genuinely doesn't have one; "the handler test already covers it" is NOT a reason to skip the route round-trip. See [docs/backend/test-framework.md](test-framework.md).

## CLI

At a brand root, `npx omega <command> --target=<name>` (bins `omega`, `omg`, `mgr`, all the same context-aware dispatcher): [docs/manager/brand.md](../manager/brand.md) § Verbs is where every verb runs, and a target folder refuses. A standalone project is its own root and drops the picker.

| Command | Description |
|---|---|
| `emulator` | Start Firebase emulators (auth/firestore/functions/database/storage); fronts the public hosting port with the mkcert HTTPS proxy (`--no-https` for plain http). A stop takes the whole family: firebase-tools puts each java emulator in its OWN process group, so the stop path signals the pids it recorded at boot, sweeps whatever orphaned outside that record, and only then verifies the ports came back free. A boot that never comes up takes the same path before it reports ([#304](https://github.com/Omega-JS-Stack/omega/issues/304)). EVERY stop path runs it: Ctrl+C (SIGINT), `omega dev`'s stop (SIGTERM), and a closed terminal (SIGHUP) share one handler, registered off the ONE list every OMEGA supervisor imports (`STOP_SIGNALS` in [@omega.js/devkit's src/stop-signals.js](../../../devkit/src/stop-signals.js), which the manager's `omega dev`, the web dev server and both log tails register too, so no supervisor can carry a subset again). So no way of stopping the dev loop leaves an emulator, a java jar, or the reload watcher behind ([#629](https://github.com/Omega-JS-Stack/omega/issues/629)). A boot also reaps the leftovers of a previous run BY PID, from that run's own record, before overwriting it — the port sweep cannot see a watcher that binds nothing — and it signals only a recorded pid whose LIVE command line still reads as this project's emulator machinery, so a recycled number that reads as anything else is left alone. A record that names no root pid of its own is not a kill order at all — staleness is proved BY the root, and an unprovable root over a live stack would read as pure leftovers ([#721](https://github.com/Omega-JS-Stack/omega/issues/721)). The allocator's probe and firebase-tools' bind are two moments, so a boot that dies on `EADDRINUSE` re-allocates around the port it could not bind, republishes the map, and boots ONE more time; a second failure names the port and, where lsof can identify it, the pid holding it, and never signals it. The record reap waits for the pids it took to actually be gone before anything probes a port, so a shutdown still unwinding can never answer "free" for a port it is about to keep ([#778](https://github.com/Omega-JS-Stack/omega/issues/778)) |
| `dev` | The dev loop the target's `start` script runs: the full emulator suite, as `emulator` boots it. Aliases `start`, `--dev`. REFUSED on a `projectType: 'custom'` backend, whose `start` is its own server |
| `serve` | Local Firebase serve (with auto Stripe webhook forwarding if keys set) |
| `watch` | Auto-reload functions on file change |
| `deploy` | Dispatch the brand's `deploy.yml` so the RUNNER deploys Cloud Functions to Firebase ([#872](https://github.com/Omega-JS-Stack/omega/issues/872)); `--direct` runs that same deploy from this machine, which is what the runner itself invokes. `--dry-run` prints the plan on either path, `--no-secrets` skips the precheck that publishes this target's secrets. REFUSED on a `projectType: 'custom'` target; see [Custom-server mode](#custom-server-mode--projecttype-custom-584) |
| `test` | Run the TARGET CHECKS (config validation, doc/script defaults, Firestore index provisioning, the audit half of the retired `setup`, [#675](https://github.com/Omega-JS-Stack/omega/issues/675)), then the project's test suites against an emulator, or with none on a custom-server backend (`framework:` / `full:` reach the framework suite). `--offline` blocks every live mutation the checks would make (deploys, bucket policy, seeding) and downgrades them to reported warnings; reads still run ([#284](https://github.com/Omega-JS-Stack/omega/issues/284)). On a `cloud.shared: true` project the live index sync is skipped whole (one dim line, no read, no merge): a shared project's deployed indexes carry every tenant brand's collections, and pulling them down rewrote the consumer's authored `firestore.indexes.json` with the other brands' definitions ([#716](https://github.com/Omega-JS-Stack/omega/issues/716)). A run that starts its OWN emulator tears the whole stack down: the emulator AND the test-runner child, which a directed signal never reaches on its own, on the same three signals `emulator` does, once per run however many arrive ([#722](https://github.com/Omega-JS-Stack/omega/issues/722)) |
| `update` | Dependency freshness report (installed/wanted/latest + patch/minor/major, < 7-day releases QUARANTINED); a bare run installs the safe set via npu, `--dry-run` only reports, `--major` explicit. Aliases: `-u`, `--update` (the same short flags every sibling framework spells, [#81](https://github.com/Omega-JS-Stack/omega/issues/81)). See docs/shared/updates.md in the Omega repo |
| `mcp` | Start the stdio MCP server (for Claude Code / Claude Desktop). Supports `--token <key>` for user-level connections |
| `firestore:get/set/query/delete` | Direct Firestore reads/writes from the terminal (emulator unless `--production`) |
| `auth:get/list/delete/set-claims` | Manage Auth users from the terminal (emulator unless `--production`) |
| `auth:token` | Mint a custom token + one-click sign-in URL (QA "log in as anyone"; emulator by default, `--production` explicit) |
| `logs:read` / `logs:tail` | Cloud Function logs from Google Cloud Logging |
| `stripe` | Standalone Stripe CLI webhook forwarding |
| `indexes` | Sync deployed Firestore indexes into `firestore.indexes.json` (aliases `indexes:get`, `firestore:indexes:get`) |
| `migrate:rules` | The one-time move of a legacy `firestore.rules` onto the compiled model — run ALONE and deliberately, because it changes what the live project enforces. The target checks defer to it instead of healing the tree on the way to a deploy ([#522](https://github.com/Omega-JS-Stack/omega/issues/522)). Alias `migrate:firestore-rules` |
| `migrate:markers` | The one-time conversion of the PRE-FAMILY marker formats a tree carried over from BEM still holds — the `{{ backend-manager }}` placeholder, the `# BEM>>>` `.gitignore` block, the `///---backend-manager---///` rules block, and the cp72-74 `///---omega---///` interim flavor — onto the family grammar. Run ALONE: every evergreen verb speaks only the family, so they detect those shapes and point here rather than converting ([#40](https://github.com/Omega-JS-Stack/omega/issues/40)) |
| `clean` | Remove node_modules + lockfile and reinstall (alias `clean:npm`) |
| `version` | Print @omega.js/backend version |
| `help` | Print the command listing (also `-h`/`--help`); bare `omega` prints it too (nothing claims the default slot since `setup` was retired), unknown commands print the listing and exit 1. The listing is GENERATED from the same command table the dispatcher reads (`src/cli/command-table.js`) — it cannot drift from what actually dispatches |

**The ported-project report is a leg of the brand root's `omega migrate`** ([#600](https://github.com/Omega-JS-Stack/omega/issues/600), [#885](https://github.com/Omega-JS-Stack/omega/issues/885)): this CLI carries no `migrate`. `npx omega migrate --target=<name>` at the brand root runs `@omega.js/backend/migrate` in-process (an exports entry beside `./ensure-target`), which names every bare `require()` under `src/` of a package this target's own package.json does not declare, file:line with the fix. BEM's FLAT install answered such a require and OMEGA's resolves it only by HOISTING, and the ones that carry it are LAZY (inside the handler), so the module loads fine and the route 500s on the first real request. REPORT ONLY, `--execute` included: which version a brand wants is the brand's call. The scan is devkit's `src/bare-requires.js`, the same one the web leg runs, so the two frameworks cannot answer differently; a backend has no bundler, so it excludes no aliases. The one-time CONVERSIONS stay run-alone verbs of this CLI (`migrate:rules`, `migrate:markers`), reached with `--target=`.

**Backend has a deploy PRECHECK now** ([#872](https://github.com/Omega-JS-Stack/omega/issues/872), in the [#675](https://github.com/Omega-JS-Stack/omega/issues/675) shape the other three already had): it had none while the deploy ran from a laptop, where the brand's own files sat right under it, and the runner has neither. The two steps are `verify-deploy-roles` (the deploy identity's IAM, below) and `push-secrets`, the latter FATAL on all four frameworks ([#891](https://github.com/Omega-JS-Stack/omega/issues/891)): the schema's backend delivery set, valued from the COMPOSED target env (company ← brand ← target, files only), plus `OMEGA_SERVICE_ACCOUNT_JSON`, the deploy credential's own bytes read from the authored key chain (the key is a FILE everywhere else, minted into the brand's `.omega/secrets/`, so it names no `.env` value). Published as repo Actions secrets over the same `gh` transport web, desktop and the extension use, against the brand's DECLARED repo. `--no-secrets` skips it, the same opt-out name the other three honor (it used to be accepted and ignored here). Soft like every precheck: it reports, the deploy proceeds. A dry run sends nothing, so it prechecks nothing. The set carries `OMEGA_LICENSE_KEY` too, as a `ci` delivery like the other three targets: the license check runs where the deploy runs, so without it every CI deploy would resolve keyless and stamp `OMEGA_LICENSE_STATUS=keyless` into the upload. `ci` is also what keeps it OUT of that upload: the workflow's writer takes the `env` deliveries only, and the stage runs the composed values through `artifactEnvValues`, so the key reaches the deploy PROCESS and never the artifact's own `.env`.

The IAM steps stay inside the verb, where they always were: `omega deploy` sets the Cloud Functions artifact cleanup policy and grants the public `allUsers` invoker on every HTTP function before it uploads — both idempotent, both skipped without a fuss when the project has nothing to set yet. One exception, on a runner only ([#872](https://github.com/Omega-JS-Stack/omega/issues/872)): the workflow installed and authenticated `gcloud` itself, so a listing of the HTTP functions that fails there FAILS the deploy by name (the functions deployed, but every HTTP function answers 403 until the `allUsers` binding exists). A laptop with no `gcloud` stays quiet as before.

**The backend deploys through a workflow like every other target** ([#872](https://github.com/Omega-JS-Stack/omega/issues/872)): its template is `src/defaults/.github/workflows/deploy.yml`, composed into the brand root as `backend-deploy.yml` by the same `composeTargetWorkflows` the other three ride, on `workflow_dispatch` alone ([#923](https://github.com/Omega-JS-Stack/omega/issues/923)) and no push trigger. So `npx omega deploy --target=backend` is a DISPATCH now, and the runner's job is: checkout (depth 1, nothing here reads git history), setup-node, the rendered firewall step, `sfw npm ci` (the brand lockfile as pushed, [#938](https://github.com/Omega-JS-Stack/omega/issues/938)), the target's `.env` written by a node one-liner that reads the generated `{{ envFileKeys }}` list out of the runner env and serializes the file through `@omega.js/config`'s own `serializeEnv` (resolved from the just-installed backend through its `@omega.js/backend/config` export, since the config package is vendored, not a dependency): no shell ever touches a secret, so a value carrying a newline can neither split a line nor inject a key of its own. Then `service-account.json` written from `OMEGA_SERVICE_ACCOUNT_JSON`, the Firebase CLI installed through the firewall (`sfw npm install -g firebase-tools@15`: the verb shells out to a GLOBAL `firebase`, the developer's tool rather than a framework dependency, and a runner starts without it), `gcloud auth activate-service-account` against that same file (the public-invoker fix shells out to `gcloud`, which reads its own credential store and ignores `GOOGLE_APPLICATION_CREDENTIALS`, so without it every CI-deployed HTTP function answers 403; the project stays implicit, every call the deploy makes passes its own `--project`), then `node "${{ github.workspace }}/node_modules/@omega.js/backend/bin/omega" deploy --direct` with `GOOGLE_APPLICATION_CREDENTIALS` exported to that file. No step in that workflow runs `npx` at all, the version-log step included ([#877](https://github.com/Omega-JS-Stack/omega/issues/877)): a bare `npx omega` on a runner where the shared bin never got linked fetches a stranger's package from the registry and runs it with the secrets in env, so the workflow resolves no bin NAME and runs this framework's own file. The job sets no `NODE_ENV` either, since `NODE_ENV=production` is what left the bin unlinked, by making npm skip every devDependency the brand declares, and its install names only this target's workspace ([deploys.md](../shared/deploys.md)). `.firebaserc` never travels (it is gitignored), and nothing has to send it: `ensureTarget` re-derives it on the runner from the resolved `cloud.config.projectId`, which is the direction that rule has always run. `--direct` is the whole of today's local behavior and is unchanged: the artifact cleanup policy, the pack step for any linked framework, `firebase deploy`, the public-invoker fix. The brand-root fan-out and `omega pipeline` pass `--direct` to the backend the way they already do for web. The lane, the secrets delivery and the pack step: [deploys.md](../shared/deploys.md).

**The runner's credential needs more roles than a laptop's** ([#878](https://github.com/Omega-JS-Stack/omega/issues/878)): a dispatched deploy authenticates as the Admin SDK service account the brand publishes as `OMEGA_SERVICE_ACCOUNT_JSON`, and the five project roles the manage walk grants it (`roles/firebase.admin`, `roles/firebaseauth.admin`, `roles/datastore.owner`, `roles/serviceusage.serviceUsageConsumer`, `roles/cloudscheduler.admin`) are not the whole set. The scheduler role is on that list because a scheduled function's deploy UPSERTS its Cloud Scheduler job and `roles/firebase.admin` does not cover the update: without it the deploy dies on `The principal lacks IAM permission cloudscheduler.jobs.update`, which the laptop's Owner login hid too. A functions deploy ACTS AS the runtime accounts the functions run under, so the key also needs `roles/iam.serviceAccountUser` on the App Engine default account (`<projectId>@appspot.gserviceaccount.com`) and the compute default account (`<projectNumber>-compute@developer.gserviceaccount.com`, gen 2). That role counts only where it is granted, on each account's OWN policy and never on the project's, and a laptop deploy never needed it because the developer's own login is Owner: the runner is where it surfaces, as `Missing permissions required for functions deploy`. The manage walk's cloud service grants it whenever it mints or verifies the key (diffed first, so a converged project writes nothing), and the `verify-deploy-roles` precheck step reads both policies through `gcloud` before the dispatch, naming a missing grant with the exact `gcloud iam service-accounts add-iam-policy-binding` command. Soft like every precheck step: a laptop with no `gcloud`, or a brand whose key has not been minted yet, reports that it could not check rather than inventing a finding.

The target checks also regenerate the OMEGA-managed block in `database.rules.json` and seed (or migrate) the brand's `firestore.rules` source — except on a brand that has DEFERRED the compiled-rules migration, where it reports and changes nothing (see [Firestore rules: compiled, not managed](#firestore-rules-compiled-not-managed)); the `(vX.Y.Z)` stamp in the marker header — and in the compiled firestore artifact's header — is `RULES_VERSION`, a rules SCHEMA version that bumps only when generated rule semantics change (never the package version). Its one home is `src/cli/utils/compile-rules.js`.

## Firestore rules: compiled, not managed

A brand's `firestore.rules` is **source**, not a file the framework rewrites ([#255](https://github.com/Omega-JS-Stack/omega/issues/255)). Firestore ORs `allow` across sibling match blocks, so a brand's own `match /users/{uid}` can only ever WIDEN access — under the old managed-marker-block model a brand had no way to protect a field of its own, and hand-edits to the managed block were wiped on the next run.

```
firestore.rules                                  ← the brand's, pure rules language
+ @omega.js/backend/templates/firestore.framework.rules   ← ships inside the package
= dist/firestore.rules                           ← GENERATED, what firebase.json points at
```

- **Where it happens**: `stageFunctions()` (`src/cli/utils/stage-functions.js`) compiles on every stage, so `omega build`, emulator/serve boot, `omega test` and `omega deploy` all read a current artifact — and the stage watch treats `firestore.rules` as a stage input, so editing it hot-reloads the running emulator. The compiled artifact opens with a header naming BOTH sources and forbidding edits.
- **`firebase.json`** points `firestore.rules` at `dist/firestore.rules` for the emulator AND `firebase deploy`. A build that finds a stale target reports it loudly.
- **Merge-by-match is how a brand TIGHTENS** ([#353](https://github.com/Omega-JS-Stack/omega/issues/353)). Both halves land in one `match /databases/{database}/documents` scope, so functions resolve across the seam in both directions and brand rules call framework helpers (`isUser`, `isAdmin`, `getExistingData`, `isWritingAny`, …). A brand match block whose path CANONICALIZES to a framework block's (wildcard names normalized, the brand's variable renamed to the framework's inside the fold-in) is merged into it:

  ```
  yours       match /users/{userId} { allow create, update: if !isWritingAny(['xp']) && isEmailVerified(); }
  framework   match /users/{uid}    { allow create, update: if isUser(uid) && !isWritingFrameworkField(); }
  compiled    match /users/{uid}    { allow create, update: if isUser(uid) && !isWritingFrameworkField() && (!isWritingAny(['xp']) && isEmailVerified()); }
  ```

  An op BOTH blocks declare gets the brand condition parenthesized and ANDed on (a framework statement listing several ops splits only as far as it must). An op only the BRAND declares appends verbatim — that op widens, exactly as a sibling block always did. Nested matches and functions inside the brand block splice in. A path the framework never declares passes through untouched.
- **The documented limit**: ops pair by NAME, so a brand `allow create` beside the framework's `allow write` does not tighten it — Firestore ORs the two. The compiler REPORTS that case rather than letting it look like a tightening. Widening a framework-declared op from the brand file is not expressible.
- **The hooks are gone.** `protectedFields()` and `canWriteUser()` (the 0.36.0 model) retired with rules v3: no lint, no re-seed, no injection. Setup strips a hook still carrying its shipped default body, KEEPS a customized one as an ordinary brand function (reported loudly — nothing calls it now), renames calls to the helpers v3 renamed, and refreshes the seed header.
- **The framework helpers** (`templates/firestore.framework.rules` is the SSOT). The naming convention is the API: **`is*` is a predicate** about the caller or about this write — `isAuthenticated()`, `isUser(identity)`, `isOwner()`, `isAdmin()`, `isEmailVerified()`, `isWritingAny(fields)`, `isWritingField(field)`, `isCreatingField(field)`, `isUpdatingField(field)`, `isWritingFrameworkField()` — and **`get*` hands back a value** to compare against: `getAuthUid()`, `getAuthEmail()`, `getRoles()`, `getExistingData()`, `getIncomingData()`. Four things to know: `getRoles()` bills ONE document read per call and is the only helper that costs anything (so every `isAdmin()` costs one too); `isEmailVerified()` reads the AUTH TOKEN (`request.auth.token.get('email_verified', false)`) and no stored field — unforgeable, unbilled, and true on the caller's very first request; `isUser()`'s EMAIL arm requires that verified token (anyone can sign up claiming any address, so an unproven claim never matches an email-keyed doc) while its uid arm does not; and `isOwner()` reads the STORED `owner` once the document exists and the INCOMING one on a create, so an update can never hand ownership to whoever is writing. `getExistingData()` reads an ABSENT document as the empty map — `resource` is null on a create and reading through it errors, which denies the whole rule, so this is what makes every field helper mean the same thing on create and on update. Field lists are TOP-LEVEL: protecting `xp.total` means listing `'xp'`.
- **The framework's `match /users/{uid}` declares `read` and `create, update`, never `write`.** `allow write` covers delete too, and a delete carries no incoming data for the field guard to read — so an owner deleting their own user document used to be denied by an evaluation ERROR. Naming the two ops the rule means leaves delete to the admin catch-all, denied by the rule. A brand tightening that block names the same ops (`allow write` beside it would widen, and the compiler says so).
- **Migration**: `npx omega migrate:rules --target=<name>` detects a legacy `// ========== OMEGA Rules (vX.Y.Z) ==========` block, extracts the non-managed region into the new source ONCE, and retargets `firebase.json`; a 0.36.0 hook-era file migrates the same way, once. It is a RUN-ALONE verb, never another verb's side effect ([#522](https://github.com/Omega-JS-Stack/omega/issues/522)): while `firebase.json` still names the brand's own rules file, that brand deploys the legacy posture deliberately, and adopting the compiled artifact changes what the live project enforces (the framework half joins, and a legacy `allow write` becomes `allow create, update`: a client deleting its own user doc flips allowed → denied). Both target checks DEFER there: they print the deferral plus this pointer, report deferred (not failed, not fixed), and continue. Once `firebase.json` points at `dist/firestore.rules`, the checks heal the source exactly as before.
- **`database.rules.json` keeps the marker model** and `storage.rules` stays a copy-if-missing deny-all scaffold — SETTLED ([#351](https://github.com/Omega-JS-Stack/omega/issues/351), 2026-08-18): neither has a framework half a brand needs to tighten, RTDB rules are a JSON tree with no function language to splice (the brand owns its sibling keys outright), and compiling either would add machinery with no merge semantics to buy. The three rules surfaces deliberately run three models.

See [docs/backend/cli-firestore-auth.md](cli-firestore-auth.md) and [docs/backend/cli-logs.md](cli-logs.md) for full flag references.

## Dependency Resolution

- **Consumer code can use `omega.require(name)`** to load any @omega.js/backend dependency from @omega.js/backend's own module context. Consumer projects do NOT need to install @omega.js/backend's transitive deps directly.
- **No bundler hook is needed here (#87).** @omega.js/web gives consumers bare imports of framework-declared libraries through an esbuild resolve hook ([docs/devkit/index.md](../devkit/index.md) owns the declared-set reader behind it), and desktop and extension through the same hook. Backend functions are NOT bundled: they run under plain node resolution, and `omega.require(name)` resolves from @omega.js/backend's own module context, which already delivers the same guarantee: the framework's copy, one copy, from the framework's installation. Bare `require('<framework dep>')` in consumer code is NOT part of the contract here; use `omega.require`.
- **@omega.js/client owns Firebase on the client side.** Consumer frontend code (web pages, extension popups and options, desktop renderers) NEVER imports Firebase directly: `firebase.firestore()` → `omega.firestore`, `firebase.auth()` → `omega.auth`. Backend code reads the Admin SDK as `omega.firebase.admin` (server-side is different).

## Development Workflow

- **🚫 NEVER use `npx omega ...` from the framework repo**: `npx omega` is for CONSUMER projects only (where the bin lives in the target's `node_modules/.bin/`). From the framework repo, use `npm test`, `npm run prepare`, etc. The `scripts` in `package.json` call `node bin/omega` directly. This applies to ALL four OMEGA frameworks (backend, web, extension, desktop).
- **🚫 NEVER run `npx omega serve` / `npx omega emulator` / `npm start`** (consumer projects): they're the user's long-running dev processes. Assume they're already running; if they aren't, **instruct the user to run them** rather than running them yourself (running them again kills theirs). To see output, **read the log files**: `logs/dev.log` for the CLI's own run, `dist/emulator.log` for the emulator's traffic, never tail/attach to the process. Running `npx omega test --target=<name>` is fine (it auto-starts its own emulator if needed).
- **Where the output logs live: two files per verb, one contains the other.** The CLI VERB tees its whole run to `<projectDir>/logs/`, the cross-framework lane every OMEGA target shares: `dev.log` (`npx omega serve` / `npx omega emulator`), `build.log` (`npx omega build`), `test.log` (`npx omega test --target=<name>`), and since the verb mirrors every child chunk, this file is a superset holding the firebase children's output too. The child-only view lives in `<projectDir>/dist/` (@omega.js/backend's deliberate exception, co-located with firebase-tools' own `*-debug.log`): `emulator.log`, `dev.log`, `test.log`, plus `deploy.log` (`npx omega deploy`) and `production.log` (`npx omega logs`). Both truncate per launch; the sweep at every verb start clears ours and never touches firebase-tools'. Full table and mechanism: [docs/shared/logging.md](../shared/logging.md); backend specifics: [docs/backend/logging.md](logging.md).
- **A credential never rides a log line.** The request, headers and user lines redact the channels the authenticator reads ([#275](https://github.com/Omega-JS-Stack/omega/issues/275)), and the route logger's `Sending response` line gets the same treatment at any depth of the payload: keys are matched lower-cased with `-` and `_` stripped (so `accessToken` and `access_token` are one key), and every name ending in `token`, `secret`, `password`, `privatekey` or `apikey`, plus `sessionCookie`, logs as `***<last 4> (<n> chars)` when it holds a string and `***(redacted object)` when it holds anything else, while a null, a boolean or a number passes through ([#796](https://github.com/Omega-JS-Stack/omega/issues/796)).
- **If the user reports an error**, check the emulator/test output for the root cause before guessing.
- **Live-test UI changes via CDP.** When working on admin dashboards or browser-facing endpoints, use the `chrome-devtools` MCP tools (screenshots, click, evaluate JS, console logs) to verify the change works in the running browser — your session auto-launches its own private Chrome on the first tool call (no setup, no ports). See [docs/backend/cdp-debugging.md](cdp-debugging.md) + `~/.claude/mcp-server/servers/chrome-devtools/CLAUDE.md`.

## Supply-Chain Security

All `npm install` calls in CLI commands (the target checks) route through the `safeInstall()` helper (`src/cli/utils/safe-install.js`). It prefixes `sfw` (Socket Firewall) when installed, blocking confirmed malware at the network level before packages reach disk. Falls back to plain npm if sfw isn't available. CI workflows get the firewall from Socket's own GitHub Action (`SocketDev/action`, firewall mode, pinned; it downloads the binary with the job's token and caches it, so a hosted runner's shared anonymous API quota never fails the step, [#871](https://github.com/Omega-JS-Stack/omega/issues/871)) and run `sfw npm ci`, the one install step every lane shares ([#938](https://github.com/Omega-JS-Stack/omega/issues/938)). The template carries only the `{{ installFirewall }}` token; the composer renders the step, once, from devkit's one pinned constant ([#872](https://github.com/Omega-JS-Stack/omega/issues/872)). Installs will **fail if sfw detects confirmed malware** in any package in the dependency tree; non-critical CVEs and quality warnings pass through.

## File Conventions

- **CommonJS** throughout. `prepare-package` copies `src/` → `dist/` 1:1 (no transforms).
- **`fs-jetpack`** over `fs` / `fs-extra` for file operations.
- One `module.exports = ...` per file.
- **Short-circuit early returns** rather than nested ifs.
- **Logical operators at the start of continuation lines** (`|| condB` on a new line, not `condA ||` trailing).
- **Firestore shorthand**: `admin.firestore().doc('users/abc123')` (path string) rather than `.collection('users').doc('abc123')`.
- **Template strings for requires**: `` require(`${functionsDir}/node_modules/@omega.js/backend`) `` rather than string concat.
- **No backwards compatibility** unless explicitly requested.
- **Routes receive whitespace-trimmed data; HTML is preserved.** Sanitize at the HTML-insertion site via `utilities.sanitize()`. Opt into the pipeline's HTML strip per route with `{ sanitize: true }`. See [docs/backend/sanitization.md](sanitization.md).
- **Match schema names to route names** — if route is `myEndpoint`, schema is `myEndpoint`.
- **Always use `ctx.respond()` for responses** — do NOT use `res.send()` directly.
- **Always use `omega.getApiUrl()` for the API URL**, never the cached `omega.project.apiUrl` property. The getter is the SSOT and auto-resolves to the local emulator in dev AND test (and production otherwise), so it's safe everywhere without passing an env arg. See [docs/backend/environment-detection.md](environment-detection.md).
- **Add Firestore composite indexes** for any compound query (`where` + `orderBy`, or multiple `where`s) to `src/cli/commands/setup-tests/helpers/required-indexes.js` (the SSOT). Without the index, queries crash with `FAILED_PRECONDITION` in production.

See [docs/backend/code-patterns.md](code-patterns.md) for code-pattern detail, [docs/backend/common-mistakes.md](common-mistakes.md) for the full anti-pattern checklist, and [docs/backend/file-naming.md](file-naming.md) for the naming table (routes / schemas / API commands / events / cron jobs / hooks).

## Doc-update parity

Whenever you make a behavioral change (new command, new flag, new pattern, removed feature), update:

1. **`README.md`** — user-facing summary
2. **`docs/backend/index.md`** (this file) — architecture overview, one paragraph or cross-link
3. **`docs/backend/<topic>.md`** — the meat. If a topic doesn't have a doc yet, create one.
4. **`CHANGELOG.md`** — if the project keeps one

Don't ship behavioral changes with stale docs. Validate first, then document — write docs that describe shipped reality, not intentions.

**The four framework guides are structurally MIRRORED.** [docs/web/index.md](../web/index.md), [docs/backend/index.md](../backend/index.md), [docs/desktop/index.md](../desktop/index.md), and [docs/extension/index.md](../extension/index.md) keep the same section skeleton in the same order. Never add, rename, or reorder a section in one without making the SAME change in the others in the same pass.

## Documentation

Deep references live in `docs/backend/`, beside this guide. **Whenever you make a behavioral change, update both this overview AND the relevant `docs/backend/*.md` deep reference.**

### Architecture & Conventions

- [docs/backend/architecture.md](architecture.md): the `Omega` instance, `Context`, dual-mode (firebase/custom), the services
- [docs/backend/directory-structure.md](directory-structure.md) — @omega.js/backend library + consumer project layouts
- [docs/backend/build-system.md](build-system.md) — no consumer build (deliberate outlier), framework prepare-package, deploy pipeline
- [docs/backend/code-patterns.md](code-patterns.md) — short-circuit returns, logical operators on new lines, Firestore shorthand, template-string requires, fs-jetpack preference
- [docs/backend/file-naming.md](file-naming.md) — naming table for routes, schemas, API commands, events, cron jobs, hooks
- [docs/backend/common-mistakes.md](common-mistakes.md): anti-pattern checklist (don't modify framework internals, always await, one `ctx.usage.consume()` call counts, etc.)
- [docs/backend/audit.md](audit.md) — full-audit check catalog (U-xx universal / @omega.js/backend-xx / F-xx IDs with severity + scope), protocol + fix loop
- [docs/backend/cdp-debugging.md](cdp-debugging.md) — launching a controllable Chrome (CDP) to verify the frontend against your routes (network payloads, auth'd flows via the persistent agent profile)
- [docs/backend/key-files.md](key-files.md): quick lookup for the most-touched files (the instance, `Context`, the pipeline, services, auth events, cron, payment providers, CLI commands)
- [docs/backend/cli-output.md](cli-output.md) — shared CLI styling module (`src/cli/utils/ui.js`): OMEGA-style banner/dividers/sections/status symbols + the `Summary` block (pass/warn/fail); setup check return types (`true`/`false`/`Error`/`'warn'`); used by the target checks, adoptable by other commands
- [docs/backend/environment-detection.md](environment-detection.md): `getEnvironment()` returns `'development' | 'testing' | 'production'` (mutually exclusive); gate side effects on the INTENTIONAL check (`isProduction()` for prod-only, `isDevelopment() || isTesting()` for local-or-test), never `!isDevelopment()`. Plus the URL helper convention (always `omega.getApiUrl()`: it resolves local in dev and test; never read `project.apiUrl`)
- [docs/backend/response-headers.md](response-headers.md) — automatic `omega-properties` header

### Building Routes & Components

- [docs/backend/routes.md](routes.md): recipes for routes (the `{ ctx, omega, user, data, usage, analytics }` handler, CRUD method files, ownership checks, firebase.json rewrites and ordering, the `src/index.js` entry, `omega.routes.run()` and the pipeline options), event handlers and `omega.events.run()`, cron jobs
- [docs/backend/schemas.md](schemas.md): the one schema system: a function of the request returning a plain declaration, the full example, the three split kinds, the field vocabulary, ID generation and `path` ids, the required-vs-default footgun
- [docs/backend/firestore.md](firestore.md) — path style, NO subcollections, batch reads (~500 cursor pagination), `metadata.{created,updated}` timestamps, response format + redaction
- [docs/backend/migration.md](migration.md): legacy-project migration: runtime config → top-level env vars, config reads → `process.env.*`, constructor routes and tiered schemas → the current format
- [docs/backend/sanitization.md](sanitization.md): the pipeline's trim-only default; opt-in HTML strip (`{ sanitize: true }`) with per-field opt-out (`sanitize: false`); manual `utilities.sanitize()` for HTML-insertion sites
- [docs/backend/auth-hooks.md](auth-hooks.md) — consumer hooks for `before-create`/`before-signin`/`on-create`/`on-delete` (blocking + non-blocking examples)
- [docs/backend/common-operations.md](common-operations.md) — inside-the-handler patterns: authenticate, read/write Firestore, error handling, send response, `omega_api` hook

### Built-in Routes

- [docs/backend/verts.md](verts.md) — house verts module (adblock-safe ad system): `verts` collection, public `GET /omega/verts/serve` (self-contained HTML unit, 204 no-fill) + fail-closed `GET /omega/verts/redirect`, admin CRUD, in-memory inventory cache (~5 min TTL), contextual targeting × weight selection
- [docs/backend/connections.md](connections.md): user connections (`/user/connections`): the stored record and its `type` ([#788](https://github.com/Omega-JS-Stack/omega/issues/788)), the two things a provider adds (a `src/connections/<name>.js` module the lane loads before its own, the two `CONNECTIONS_<PROVIDER>_*` env keys), `pkce: 'S256'` as a declaration, the ONE context every step takes and the `authorize`/`exchange`/`identity`/`refresh`/`revoke`/`status` table, the route-owned identity uniqueness and the config-defaults card rule ([#793](https://github.com/Omega-JS-Stack/omega/issues/793)), whose card keys `packages/config/test/defaults.test.js` pins to the packaged provider files, one card per `providers/<name>.js` ([#1012](https://github.com/Omega-JS-Stack/omega/issues/1012)), and how another target reads or refreshes the token ([#771](https://github.com/Omega-JS-Stack/omega/issues/771)): plus the cross-instance refresh lease and the `{ success, token }` answer ([#783](https://github.com/Omega-JS-Stack/omega/issues/783)) and the public client that sends no `client_secret` ([#785](https://github.com/Omega-JS-Stack/omega/issues/785))
- [docs/backend/admin-post-route.md](admin-post-route.md): `POST/PUT /admin/post` blog creation via GitHub (image extraction + resize at ingest + `@post/` rewriting). Also the publish target for the Ghostii article engine (`libraries/content/ghostii.js`). Every CMS route that touches repo content (`/admin/post`, `/admin/repo/content`, `/content/post`) takes a `target` naming the web target ([#887](https://github.com/Omega-JS-Stack/omega/issues/887)): optional for a brand with one web target, REQUIRED when it runs several (a missing or unknown name answers 400 with the declared list), and the commit path is `targetPath(config, target)` plus the site-relative path (`targets/<name>/src/_posts/...`), never composed by hand.
- [docs/backend/payment-system.md](payment-system.md): full payment pipeline: Intent → Webhook → On-Write → Transition; subscription model, statuses, the `User` getters (`plan`, `active`, `trialing`), transition handlers, the provider capability registry (one descriptor per provider, the one home of what each can do), provider interface (Stripe, PayPal, Chargebee, Coinbase Commerce for crypto one-time purchases, test), webhook verification (the shared `?key=` param, the one check), product config, test provider
- [docs/backend/paypal-sandbox-qa.md](paypal-sandbox-qa.md) — the live PayPal sandbox QA drive: standing fixtures (creds, webhook, the trial-free `proof-press` product — listed on /pricing on purpose, the hand-made sandbox buyer — PayPal has no account-creation API), the subscription sale → refund sequence, and the gotchas
- [docs/backend/marketing-campaigns.md](marketing-campaigns.md) — campaign CRUD routes, recurring campaigns, generator pipeline (newsletter), newsletter-driven blog article (`content.article.enabled`), template-owned schemas, asset hosting, seed campaigns
- [docs/backend/consent.md](consent.md) — marketing consent capture: canonical `consent.{legal,marketing}` user-doc shape, signup-form capture, account-page toggle, HMAC unsub link (cross-provider unsub + re-add on resubscribe), admin contact-DELETE revoke mirror, SendGrid+Beehiiv webhook receivers, parent forwarder (`/marketing/webhook/forward`), library-level consent gate in `email.add()`/`email.sync()` (revoked-only skip), migration script template
- [docs/backend/mcp.md](mcp.md) — Model Context Protocol server: 28 tools with role-based scoping (24 admin / 2 user / 2 public), tool annotations (title, read/write hints), OAuth 2.1 with PKCE + dynamic client registration + consumer website sign-in, consumer MCP tools (`src/mcp.js`), HTTPS local dev (mkcert), Claude Desktop/Chat/Code configuration

### Subsystems & Libraries

- [docs/backend/ghostii.md](ghostii.md) — Blog auto-publisher (Ghostii provider): source types (`$brand` / `$feed:` / `$parent` / URL / text), provider-based architecture, per-entry API overrides, RSS/Atom feed parser, unified `content-sources` Firestore tracking, `sourceContent` pass-through to Ghostii API
- [docs/backend/email-system.md](email-system.md) — unified MJML email rendering pipeline: shared preparation (`prepare.js`), composable template system (`base.js` blocks), 4 email templates (card, plain, order, feedback), no SendGrid dynamic templates — everything rendered server-side
- [docs/backend/usage-rate-limiting.md](usage-rate-limiting.md) — the counted-feature gate ([#647](https://github.com/Omega-JS-Stack/omega/issues/647)): ONE call, `await ctx.usage.consume('<feature>')`, checks both counters (month and the day's share of it), refuses with a 429 naming which one hit, else counts and writes. What a feature IS lives once in the top-level `features` catalog and each product names only its VALUE; per-user overrides on the user doc win over the plan's number; mirrors are declared in the catalog, not at the call site; anonymous counting is explicit (`usage.forKey(ip)`); init is lazy, so a route that never counts pays nothing
- [docs/backend/ai-library.md](ai-library.md): `omega.ai` / `ctx.ai`, the unified entry for OpenAI and Anthropic (text via `.request()`, images via `.image()` → `gpt-image-2`)
- [docs/backend/marketing-fields.md](marketing-fields.md) — adding custom fields to SendGrid + Beehiiv via the @omega.js/backend/OMEGA SSOT pair
- [docs/backend/stripe-webhook-forwarding.md](stripe-webhook-forwarding.md) — auto-started Stripe CLI forwarding for local dev, and the shared key the forwarded deliveries carry

### Testing & CLI

- [docs/backend/test-framework.md](test-framework.md): running, filtering, log files, test types (standalone/suite/group), context object, assertions, auth levels. **NEVER mock: test against the real emulator.** No mock instance, mock admin, fake `firestore` or stubbed `ctx`: every `run()` gets the real `omega`, `ctx`, `firestore`, `http` and `accounts`; use them. Pure functions (zero I/O) are the only thing you call directly; anything touching Firestore or an external API runs for real. Real external APIs (OpenAI/PayPal/GitHub/SendGrid/Stripe) are gated behind `TEST_EXTENDED_MODE` in-source (not mocked): opt in with `--extended` or `TEST_EXTENDED_MODE=true` (shared, unprefixed across all four frameworks; propagates to BOTH runner and emulator), and anything an extended test creates externally must be cleaned up by the test. **Each test file `module.exports` a `{ description, type, tests }` object, NOT raw Mocha (`describe`/`it`/`beforeEach`); those globals are not injected and the file fails to load. The only lifecycle hook is `cleanup`: exported `before`/`after` properties are silently IGNORED (do setup inside the tests via an idempotent helper, or in `test/_init.js`). Split tests one-file-per-concern under `test/<area>/`, never one giant `test/test.js`.** **All cleanup runs at the START of every run, never at the end**: the runner flushes the ENTIRE emulator Firestore before every run, so there's nothing to register; seed any needed fixtures in `test/_init.js`'s `setup()`, and never add a trailing cleanup step. Marketing providers (SendGrid/Beehiiv) don't need a special exception: `_test.*` emails are blocked at the validation layer so test signups never reach providers. The `_test.allow_*` carve-out exists only for the live-provider lifecycle test (`test/marketing/consent-lifecycle.js`), which manages its own teardown.
- [docs/backend/test-boot-layer.md](test-boot-layer.md): the `boot/` smoke layer: framework self-test from the repo via the bundled fixture project + `OMEGA_TEST_BOOT_PROJECT` (the backend's analog of the extension's and web's `*_TEST_BOOT_PROJECT`)
- [docs/backend/cli-firestore-auth.md](cli-firestore-auth.md) — `npx omega firestore:*` and `auth:*` commands, shared flags, examples
- [docs/backend/cli-logs.md](cli-logs.md) — `npx omega logs:read` / `logs:tail` with full flag reference and built-in Cloud Function names
- [docs/backend/logging.md](logging.md) — `dist/*.log` file table (the `dist/` location exception — co-located with firebase-tools' debug logs), `production.log`
