# Common Mistakes to Avoid

1. **Defining a local `escapeHTML` / `sanitizeURL` helper**: use the canonical inline form `omega.utilities.escapeHTML(value)` / `omega.utilities.sanitizeURL(url)` at every call site. Do NOT alias / destructure / `.bind()`. This is the most common XSS-introduction vector in @omega.js/extension extensions.
2. **Using raw `chrome.*` instead of `extension.*`** — Use the extension API wrapper for cross-browser compat (Chrome / Firefox / Edge).
3. **Putting service-worker-incompatible code in `background`** — Service workers can't hold WebSockets or long-running state. Use the `offscreen` component for persistent work.
4. **Trying to share `omega` state across components**: each component context has its own `omega` instance in its own JavaScript context. Use `omega.messenger` / `extension.storage` to communicate.
5. **Writing `<html>`/`<head>`/`<body>` in component views** — Views are HTML fragments; @omega.js/extension wraps them with `page-template.html` at build time.
6. **Hand-editing `dist/manifest.json` or `dist/*` files** — Edit `config/manifest.json` (or component sources); @omega.js/extension regenerates dist on every build.
7. **Installing @omega.js/extension's dependencies as direct consumer deps**: consumer projects must NOT `npm install firebase`, `@omega.js/client`, or any other @omega.js/extension/@omega.js/client transitive dep. The bundler's framework-deps hook re-resolves every name @omega.js/extension DECLARES from the framework's own `node_modules/`. If a dependency isn't resolving, the fix is in @omega.js/extension's `package.json`, not the consumer's. Same rule on every OMEGA framework.
8. **Touching Firebase directly in consumer code**: Firebase is owned by @omega.js/client. Consumer code NEVER does `import firebase from 'firebase/app'` or `require('firebase')`. Instead: the context's instance, `omega.auth`, `omega.firestore`. Same rule on every OMEGA browser surface.
