# IPC

Typed channel bus for main ↔ renderer communication. All @omega.js/desktop features register their channels through this single layer rather than calling `ipcMain.handle` directly, so you have one place to look and one place to instrument.

## Main-process API

```js
manager.ipc.handle(channel, async (payload, evt) => result)   // request/response
manager.ipc.unhandle(channel)
manager.ipc.invoke(channel, payload)                          // call locally (also what renderer triggers)
manager.ipc.on(channel, (payload, evt) => void)               // one-way subscribe (renderer → main)
manager.ipc.off(channel, fn)
manager.ipc.broadcast(channel, payload)                       // → all BrowserWindows
manager.ipc.send(webContents, channel, payload)               // → one renderer
manager.ipc.hasHandler(channel)
manager.ipc.listenerCount(channel)
```

## Renderer-process API (via preload contextBridge)

```js
await window.desktop.ipc.invoke(channel, payload)   // → Promise<result>
const off = window.desktop.ipc.on(channel, (payload) => { ... });
window.desktop.ipc.send(channel, payload);          // fire-and-forget
```

## Channel naming

framework-internal channels are prefixed `desktop:` (e.g. `desktop:storage:get`, `desktop:storage:change`). Consumers are free to use any namespace.

## Validation

- `handle()` throws if `channel` is empty/non-string or `handler` is non-function.
- `handle()` throws on duplicate registration. Call `unhandle()` first if you need to swap.
- `invoke()` rejects with a clear message if no handler is registered for the channel.
- Handler errors propagate through `invoke()` (both main-local and renderer-side) — your renderer's `await window.desktop.ipc.invoke(...)` will reject with the original error message.

## Zero-trust payloads

Registration is validated for you (above) — payload CONTENT is not. Treat every payload reaching a `handle()` / `on()` callback as untrusted input: renderers can be compromised, and apps that embed remote web content (e.g. external pages in `WebContentsView`s) expose the IPC surface to code you don't control.

- **Validate shape and values before acting** — types match, IDs are well-formed, enums are from the expected set, paths resolve inside the expected roots.
- **Gate any URL arriving via IPC** through `sanitize-url.js` before `shell.openExternal` / `loadURL` (the zero-trust URL rule — see [common-mistakes.md](common-mistakes.md)).
- **Never feed raw payload values** into filesystem paths, shell commands, or `webContents.executeJavaScript`.

## Boot order

`ipc` initializes **before** `storage` so that storage (and every other feature) can register handlers via `ipc.handle`. This is the canonical pattern: don't touch `ipcMain` directly.

## Example

```js
// main
manager.ipc.handle('user:get-token', async (payload) => {
  const token = await fetchToken(payload.userId);
  return { token };
});

// renderer
const { token } = await window.desktop.ipc.invoke('user:get-token', { userId: 'abc' });
```
