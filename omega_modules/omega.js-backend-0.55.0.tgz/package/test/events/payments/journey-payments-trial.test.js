/**
 * Test: Payment Journey - Trial
 * Simulates: basic user → trial activation via test intent → trial ends → active paid
 *
 * Uses the test provider for initial trial, then manual webhook for trial-to-active
 * Product-agnostic: resolves the first paid product from config.payment.products
 */

const defineCases = require('../../../dist/vendor/devkit/test/define-cases.js');
module.exports = defineCases({
  description: 'Payment journey: basic → trial → active paid via test provider',
  type: 'suite',
  timeout: 30000,

  tests: [
    {
      name: 'verify-starts-as-basic',
      async run({ accounts, firestore, assert, state, config, skip, payments }) {
        const uid = accounts['journey-payments-trial'].uid;
        const userDoc = await firestore.get(`users/${uid}`);

        assert.ok(userDoc, 'User doc should exist');
        assert.equal(userDoc.subscription?.product?.id, 'basic', 'Should start as basic');
        assert.equal(userDoc.subscription?.trial?.claimed, false, 'Trial should not be claimed');

        // Resolve first paid product WITH a trial from config. The test provider
        // only creates a trialing subscription when product.trial.days > 0, so a
        // brand whose paid products all have trial.days: 0 (e.g. trials disabled)
        // has nothing to exercise here — skip the journey. This is a config-gap,
        // not a code failure, and mirrors journey-payments-trial-cancel.js.
        const paidProduct = config.payment.products.find(p => p.id !== 'basic' && p.prices && p.trial?.days);
        if (!paidProduct) {
          skip('No paid product with trial configured in this brand');
        }

        state.uid = uid;
        state.paidProductId = paidProduct.id;
        state.product = payments.products[paidProduct.id];
      },
    },

    {
      name: 'create-trial-intent',
      async run({ http, assert, state }) {
        const response = await http.as('journey-payments-trial').post('omega/payments/intent', {
          provider: 'test',
          productId: state.paidProductId,
          frequency: state.product.frequency,
          trial: true,
        });

        assert.isSuccess(response, 'Intent should succeed');
        assert.ok(response.data.id, 'Should return intent ID');
        assert.ok(response.data.orderId, 'Should return orderId');

        state.intentId = response.data.id;
        state.orderId = response.data.orderId;

        // Derive webhook event ID from intent ID (same timestamp)
        state.eventId = response.data.id.replace('_test-cs-', '_test-evt-');
      },
    },

    {
      name: 'trial-activated',
      async run({ firestore, assert, state, waitFor }) {
        // Poll until trial subscription appears
        await waitFor(async () => {
          const userDoc = await firestore.get(`users/${state.uid}`);
          return userDoc?.subscription?.trial?.claimed === true;
        }, 15000, 500);

        const userDoc = await firestore.get(`users/${state.uid}`);

        assert.equal(userDoc.subscription.product.id, state.paidProductId, `Product should be ${state.paidProductId}`);
        assert.equal(userDoc.subscription.status, 'active', 'Status should be active');
        assert.equal(userDoc.subscription.trial.claimed, true, 'Trial should be claimed');
        assert.equal(userDoc.subscription.payment.orderId, state.orderId, 'Order ID should match intent');

        state.subscriptionId = userDoc.subscription.payment.resourceId;

        // Verify the auto-fired webhook triggered new-subscription (trial is a property, not a separate transition)
        const webhookDoc = await firestore.get(`payments-webhooks/${state.eventId}`);
        assert.ok(webhookDoc, 'Webhook doc should exist');
        assert.equal(webhookDoc.transition, 'new-subscription', 'Transition should be new-subscription (trial detected inside handler)');
        assert.equal(webhookDoc.orderId, state.orderId, 'Webhook doc orderId should match intent');
      },
    },

    {
      name: 'intent-doc-completed',
      async run({ firestore, assert, state }) {
        const intentDoc = await firestore.get(`payments-intents/${state.orderId}`);

        assert.ok(intentDoc, 'Intent doc should exist');
        assert.equal(intentDoc.id, state.orderId, 'ID should match orderId');
        assert.equal(intentDoc.status, 'completed', 'Intent status should be completed after webhook processing');
        assert.ok(intentDoc.metadata?.completed?.timestampUNIX > 0, 'Completed timestamp should be set');
      },
    },

    {
      name: 'order-doc-created',
      async run({ firestore, assert, state }) {
        const orderDoc = await firestore.get(`payments-orders/${state.orderId}`);

        assert.ok(orderDoc, 'Order doc should exist');
        assert.equal(orderDoc.id, state.orderId, 'ID should match orderId');
        assert.equal(orderDoc.type, 'subscription', 'Type should be subscription');
        assert.equal(orderDoc.owner, state.uid, 'Owner should match');
        assert.equal(orderDoc.unified.product.id, state.paidProductId, `Product should be ${state.paidProductId}`);
        assert.equal(orderDoc.unified.trial.claimed, true, 'Trial should be claimed');
        assert.ok(orderDoc.requests !== undefined, 'requests field should exist');
        assert.equal(orderDoc.requests.cancellation, null, 'requests.cancellation should be null');
        assert.equal(orderDoc.requests.refund, null, 'requests.refund should be null');
      },
    },

    {
      name: 'send-trial-to-active-webhook',
      async run({ http, assert, state, config, payments }) {
        const futureDate = new Date();
        futureDate.setMonth(futureDate.getMonth() + 1);

        state.eventId2 = `_test-evt-journey-trial-active-${Date.now()}`;

        const response = await http.as('none').post(`omega/payments/webhook?provider=test&key=${config.webhookKey}`, {
          id: state.eventId2,
          type: 'customer.subscription.updated',
          data: {
            object: {
              id: state.subscriptionId,
              object: 'subscription',
              status: 'active',
              metadata: { uid: state.uid, orderId: state.orderId },
              cancel_at_period_end: false,
              canceled_at: null,
              current_period_end: Math.floor(futureDate.getTime() / 1000),
              current_period_start: Math.floor(Date.now() / 1000),
              start_date: Math.floor(Date.now() / 1000) - 86400 * 14,
              trial_start: Math.floor(Date.now() / 1000) - 86400 * 14,
              trial_end: Math.floor(Date.now() / 1000),
              plan: { product: payments.stripeProductIds[state.paidProductId], interval: state.product.interval },
            },
          },
        });

        assert.isSuccess(response, 'Webhook should be accepted');
      },
    },

    {
      name: 'trial-transitioned-to-active',
      async run({ firestore, assert, state, waitFor }) {
        await waitFor(async () => {
          const doc = await firestore.get(`payments-webhooks/${state.eventId2}`);
          return doc?.status === 'completed';
        }, 15000, 500);

        // Trial → active paid is the same status/product, so no transition fires
        const webhookDoc = await firestore.get(`payments-webhooks/${state.eventId2}`);
        assert.equal(webhookDoc.transition, null, 'No transition (same status/product, trial already claimed)');

        const userDoc = await firestore.get(`users/${state.uid}`);

        assert.equal(userDoc.subscription.product.id, state.paidProductId, `Product should be ${state.paidProductId}`);
        assert.equal(userDoc.subscription.status, 'active', 'Status should be active');
        assert.equal(userDoc.subscription.trial.claimed, true, 'Trial should remain claimed (historical)');
        assert.equal(userDoc.subscription.payment.frequency, state.product.frequency, `Frequency should be ${state.product.frequency}`);
      },
    },
  ],
});
