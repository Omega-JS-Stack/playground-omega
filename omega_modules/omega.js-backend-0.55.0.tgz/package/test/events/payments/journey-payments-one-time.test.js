/**
 * Test: Payment Journey - One-Time Purchase
 * Simulates: user → test intent (one-time product) → auto-webhook → purchase-completed
 *
 * Uses the test provider to exercise the full intent→webhook→trigger pipeline
 * for one-time payments. Unlike subscriptions, one-time payments only write to
 * payments-orders/{orderId} — they do NOT modify users/{uid}.subscription.
 *
 * Requires at least one product with type: 'one-time' in config.payment.products
 */

const defineCases = require('../../../dist/vendor/devkit/test/define-cases.js');
module.exports = defineCases({
  description: 'Payment journey: one-time purchase via test intent → purchase-completed',
  type: 'suite',
  timeout: 30000,

  tests: [
    {
      name: 'resolve-one-time-product',
      async run({ accounts, firestore, assert, state, config, skip }) {
        const uid = accounts['journey-payments-one-time'].uid;
        const userDoc = await firestore.get(`users/${uid}`);

        assert.ok(userDoc, 'User doc should exist');

        // Resolve first one-time product from config. If the brand has none configured,
        // skip the entire journey — this is a config-gap, not a code failure.
        const oneTimeProduct = config.payment.products.find(p => p.type === 'one-time' && p.prices?.once);
        if (!oneTimeProduct) {
          skip('No one-time product configured in this brand');
        }

        state.uid = uid;
        state.productId = oneTimeProduct.id;
        state.productName = oneTimeProduct.name;
        state.price = oneTimeProduct.prices.once;

        // Snapshot subscription before purchase — should remain unchanged after
        state.subscriptionBefore = userDoc.subscription || null;
      },
    },

    {
      name: 'create-one-time-intent',
      async run({ http, assert, state }) {
        const response = await http.as('journey-payments-one-time').post('omega/payments/intent', {
          provider: 'test',
          productId: state.productId,
        });

        assert.isSuccess(response, 'Intent should succeed');
        assert.ok(response.data.id, 'Should return intent ID');
        assert.ok(response.data.orderId, 'Should return orderId');
        assert.match(response.data.orderId, /^\d{4}-\d{4}-\d{4}$/, 'orderId should be XXXX-XXXX-XXXX format');
        assert.ok(response.data.url, 'Should return URL');

        state.intentId = response.data.id;
        state.orderId = response.data.orderId;

        // Derive webhook event ID from intent ID (same timestamp)
        state.eventId = response.data.id.replace('_test-cs-', '_test-evt-');
      },
    },

    {
      name: 'webhook-transition-purchase-completed',
      async run({ firestore, assert, state, waitFor }) {
        // Poll until the webhook is processed
        await waitFor(async () => {
          const doc = await firestore.get(`payments-webhooks/${state.eventId}`);
          return doc?.status === 'completed';
        }, 15000, 500);

        const webhookDoc = await firestore.get(`payments-webhooks/${state.eventId}`);
        assert.ok(webhookDoc, 'Webhook doc should exist');
        assert.equal(webhookDoc.transition, 'purchase-completed', 'Transition should be purchase-completed');
        assert.equal(webhookDoc.orderId, state.orderId, 'Webhook doc orderId should match intent');
        assert.equal(webhookDoc.event?.category, 'one-time', 'Category should be one-time');
      },
    },

    {
      name: 'order-doc-created',
      async run({ firestore, assert, state }) {
        const orderDoc = await firestore.get(`payments-orders/${state.orderId}`);

        assert.ok(orderDoc, 'Order doc should exist');
        assert.equal(orderDoc.id, state.orderId, 'ID should match orderId');
        assert.equal(orderDoc.type, 'one-time', 'Type should be one-time');
        assert.equal(orderDoc.owner, state.uid, 'Owner should match');
        assert.equal(orderDoc.provider, 'test', 'Provider should be test');
        assert.equal(orderDoc.unified.product.id, state.productId, `Product should be ${state.productId}`);
        assert.equal(orderDoc.unified.payment.provider, 'test', 'Unified provider should be test');
        assert.equal(orderDoc.unified.payment.orderId, state.orderId, 'Unified orderId should match');
        assert.ok(orderDoc.requests !== undefined, 'requests field should exist');
        assert.equal(orderDoc.requests.cancellation, null, 'requests.cancellation should be null');
        assert.equal(orderDoc.requests.refund, null, 'requests.refund should be null');
      },
    },

    {
      name: 'subscription-unchanged',
      async run({ firestore, assert, state }) {
        // One-time payments must NOT modify users/{uid}.subscription
        const userDoc = await firestore.get(`users/${state.uid}`);
        const subAfter = userDoc.subscription || null;

        assert.deepEqual(
          subAfter?.product?.id,
          state.subscriptionBefore?.product?.id,
          'Subscription product should be unchanged after one-time purchase',
        );
        assert.deepEqual(
          subAfter?.status,
          state.subscriptionBefore?.status,
          'Subscription status should be unchanged after one-time purchase',
        );
      },
    },

    {
      name: 'webhook-without-metadata-resolves-from-the-order',
      async run({ http, firestore, assert, state, config, waitFor }) {
        // A redelivery that carries no metadata (no uid, no orderId) — the shape a
        // provider sends when the checkout's metadata never made it onto the event.
        // The test provider answers it the way a real API would: from the order the
        // first webhook already wrote, matched on its resourceId.
        state.bareEventId = `_test-evt-one-time-bare-${Date.now()}`;

        const response = await http.as('none').post(`omega/payments/webhook?provider=test&key=${config.webhookKey}`, {
          id: state.bareEventId,
          type: 'checkout.session.completed',
          data: {
            object: {
              id: state.intentId,
              object: 'checkout.session',
              mode: 'payment',
              status: 'complete',
            },
          },
        });

        assert.isSuccess(response, 'Webhook should be accepted');

        await waitFor(async () => {
          const doc = await firestore.get(`payments-webhooks/${state.bareEventId}`);
          return doc?.status === 'completed' || doc?.status === 'failed';
        }, 15000, 500);

        const webhookDoc = await firestore.get(`payments-webhooks/${state.bareEventId}`);

        assert.equal(webhookDoc.status, 'completed', `Webhook should complete (error: ${webhookDoc.error || 'none'})`);
        assert.equal(webhookDoc.owner, state.uid, 'UID should be reconstructed from the order');
        assert.equal(webhookDoc.orderId, state.orderId, 'Order ID should be reconstructed from the order');
      },
    },

    {
      name: 'intent-doc-completed',
      async run({ firestore, assert, state }) {
        const intentDoc = await firestore.get(`payments-intents/${state.orderId}`);

        assert.ok(intentDoc, 'Intent doc should exist');
        assert.equal(intentDoc.id, state.orderId, 'ID should match orderId');
        assert.equal(intentDoc.intentId, state.intentId, 'Intent ID should match provider session ID');
        assert.equal(intentDoc.owner, state.uid, 'Owner should match');
        assert.equal(intentDoc.provider, 'test', 'Provider should be test');
        assert.equal(intentDoc.status, 'completed', 'Intent status should be completed after webhook processing');
        assert.equal(intentDoc.productId, state.productId, `Product should be ${state.productId}`);
        assert.ok(intentDoc.metadata?.completed?.timestampUNIX > 0, 'Completed timestamp should be set');
      },
    },
  ],
});
