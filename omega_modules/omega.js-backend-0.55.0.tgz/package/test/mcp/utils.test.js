/**
 * Test: MCP utility functions
 * Tests resolveAuthInfo, filterToolsByRole, loadConsumerTools, buildToolMap
 *
 * Run: npx omega test backend:mcp/utils
 */
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const defineCases = require('../../dist/vendor/devkit/test/define-cases.js');

module.exports = defineCases({
  description: 'MCP utility functions',
  type: 'group',

  tests: [
    // --- resolveAuthInfo ---

    {
      name: 'resolveAuthInfo: admin key returns admin role',
      async run() {
        const { resolveAuthInfo } = require('../../dist/mcp/utils.js');
        const saved = process.env.OMEGA_ADMIN_KEY;

        try {
          process.env.OMEGA_ADMIN_KEY = 'test-admin-key';
          const result = resolveAuthInfo('test-admin-key');

          assert.equal(result.role, 'admin', 'Should be admin');
          assert.equal(result.authType, 'adminKey', 'Should be adminKey type');
          assert.equal(result.token, 'test-admin-key', 'Token should match');
        } finally {
          process.env.OMEGA_ADMIN_KEY = saved;
        }
      },
    },

    {
      name: 'resolveAuthInfo: non-admin token returns user role',
      async run() {
        const { resolveAuthInfo } = require('../../dist/mcp/utils.js');
        const result = resolveAuthInfo('some-user-api-key');

        assert.equal(result.role, 'user', 'Should be user');
        assert.equal(result.authType, 'userToken', 'Should be userToken type');
      },
    },

    {
      name: 'resolveAuthInfo: empty token returns public role',
      async run() {
        const { resolveAuthInfo } = require('../../dist/mcp/utils.js');
        const result = resolveAuthInfo('');

        assert.equal(result.role, 'public', 'Should be public');
        assert.equal(result.authType, 'none', 'Should be none type');
        assert.equal(result.token, '', 'Token should be empty');
      },
    },

    {
      name: 'resolveAuthInfo: null/undefined token returns public role',
      async run() {
        const { resolveAuthInfo } = require('../../dist/mcp/utils.js');

        assert.equal(resolveAuthInfo(null).role, 'public', 'null should be public');
        assert.equal(resolveAuthInfo(undefined).role, 'public', 'undefined should be public');
      },
    },

    {
      name: 'resolveAuthInfo: returns public when OMEGA_ADMIN_KEY is not set',
      async run() {
        const { resolveAuthInfo } = require('../../dist/mcp/utils.js');
        const saved = process.env.OMEGA_ADMIN_KEY;

        try {
          delete process.env.OMEGA_ADMIN_KEY;
          const result = resolveAuthInfo('any-token');

          assert.equal(result.role, 'user', 'Non-empty token with no config key should be user');
        } finally {
          process.env.OMEGA_ADMIN_KEY = saved;
        }
      },
    },

    {
      name: 'resolveAuthInfo: the admin key check goes through safeCompare',
      async run() {
        // Swap the helper in the require cache and load a fresh utils.js against it,
        // restoring both entries so later cases keep the real modules.
        const safeComparePath = require.resolve('../../dist/omega/helpers/safe-compare.js');
        const utilsPath = require.resolve('../../dist/mcp/utils.js');
        const realSafeCompare = require(safeComparePath);
        const savedSafeCompare = require.cache[safeComparePath];
        const savedUtils = require.cache[utilsPath];
        const saved = process.env.OMEGA_ADMIN_KEY;
        const calls = [];

        try {
          require.cache[safeComparePath] = {
            id: safeComparePath,
            filename: safeComparePath,
            loaded: true,
            exports: (a, b) => {
              calls.push([a, b]);
              return realSafeCompare(a, b);
            },
          };
          delete require.cache[utilsPath];
          process.env.OMEGA_ADMIN_KEY = 'test-admin-key';

          const { resolveAuthInfo } = require(utilsPath);
          const result = resolveAuthInfo('test-admin-key');

          assert.equal(result.role, 'admin', 'Should still classify the admin key as admin');
          assert.deepEqual(calls, [['test-admin-key', 'test-admin-key']], 'safeCompare receives the presented token and the admin key');
        } finally {
          process.env.OMEGA_ADMIN_KEY = saved;
          require.cache[safeComparePath] = savedSafeCompare;
          if (savedUtils) {
            require.cache[utilsPath] = savedUtils;
          } else {
            delete require.cache[utilsPath];
          }
        }
      },
    },

    // --- filterToolsByRole ---

    {
      name: 'filterToolsByRole: admin sees all roles',
      async run() {
        const { filterToolsByRole } = require('../../dist/mcp/utils.js');
        const tools = [
          { name: 'a', role: 'admin' },
          { name: 'b', role: 'user' },
          { name: 'c', role: 'public' },
        ];
        const result = filterToolsByRole(tools, 'admin');

        assert.equal(result.length, 3, 'Admin should see all 3');
      },
    },

    {
      name: 'filterToolsByRole: user sees user + public only',
      async run() {
        const { filterToolsByRole } = require('../../dist/mcp/utils.js');
        const tools = [
          { name: 'a', role: 'admin' },
          { name: 'b', role: 'user' },
          { name: 'c', role: 'public' },
        ];
        const result = filterToolsByRole(tools, 'user');

        assert.equal(result.length, 2, 'User should see 2');
        assert.ok(result.some((t) => t.name === 'b'), 'Should include user tool');
        assert.ok(result.some((t) => t.name === 'c'), 'Should include public tool');
        assert.ok(!result.some((t) => t.name === 'a'), 'Should exclude admin tool');
      },
    },

    {
      name: 'filterToolsByRole: public sees public only',
      async run() {
        const { filterToolsByRole } = require('../../dist/mcp/utils.js');
        const tools = [
          { name: 'a', role: 'admin' },
          { name: 'b', role: 'user' },
          { name: 'c', role: 'public' },
        ];
        const result = filterToolsByRole(tools, 'public');

        assert.equal(result.length, 1, 'Public should see 1');
        assert.equal(result[0].name, 'c', 'Should be the public tool');
      },
    },

    {
      name: 'filterToolsByRole: tools without role default to admin',
      async run() {
        const { filterToolsByRole } = require('../../dist/mcp/utils.js');
        const tools = [{ name: 'no-role' }];

        assert.equal(filterToolsByRole(tools, 'admin').length, 1, 'Admin should see role-less tool');
        assert.equal(filterToolsByRole(tools, 'user').length, 0, 'User should not see role-less tool');
        assert.equal(filterToolsByRole(tools, 'public').length, 0, 'Public should not see role-less tool');
      },
    },

    {
      name: 'filterToolsByRole: unknown role treated as public',
      async run() {
        const { filterToolsByRole } = require('../../dist/mcp/utils.js');
        const tools = [
          { name: 'a', role: 'admin' },
          { name: 'b', role: 'user' },
          { name: 'c', role: 'public' },
        ];
        const result = filterToolsByRole(tools, 'garbage');

        assert.equal(result.length, 1, 'Unknown role should see public only');
      },
    },

    // --- loadConsumerTools ---

    {
      name: 'loadConsumerTools: returns empty array when no cwd',
      async run() {
        const { loadConsumerTools } = require('../../dist/mcp/utils.js');

        assert.equal(loadConsumerTools(null).length, 0, 'null cwd');
        assert.equal(loadConsumerTools('').length, 0, 'empty cwd');
        assert.equal(loadConsumerTools(undefined).length, 0, 'undefined cwd');
      },
    },

    {
      name: 'loadConsumerTools: returns empty array for non-existent directory',
      async run() {
        const { loadConsumerTools } = require('../../dist/mcp/utils.js');
        const result = loadConsumerTools('/tmp/does-not-exist-12345');

        assert.equal(result.length, 0, 'Should return empty array');
      },
    },

    {
      name: 'loadConsumerTools: a route tool path without the leading slash is refused by name',
      async run() {
        const { loadConsumerTools } = require('../../dist/mcp/utils.js');
        const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'omega-backend-mcp-'));

        fs.writeFileSync(path.join(cwd, 'mcp.js'), `module.exports = [
          { name: 'list_notes', description: 'List notes', method: 'GET', path: 'notes' },
        ];`);

        assert.throws(
          () => loadConsumerTools(cwd),
          /Consumer tool "list_notes" path "notes" must be the HTTP path as served, starting with "\/"/,
          'the path is taken as served, so a relative one is a load-time error',
        );
      },
    },

    // --- buildToolMap ---

    {
      name: 'buildToolMap: consumer tools override built-ins with same name',
      async run() {
        const { buildToolMap } = require('../../dist/mcp/utils.js');
        const builtin = [{ name: 'tool_a', description: 'original' }];
        const consumer = [{ name: 'tool_a', description: 'override', _consumer: true }];

        const map = buildToolMap(builtin, consumer);
        assert.equal(map.get('tool_a').description, 'override', 'Consumer should override');
        assert.equal(map.get('tool_a')._consumer, true, 'Should be marked as consumer');
      },
    },

    {
      name: 'buildToolMap: merges non-overlapping tools',
      async run() {
        const { buildToolMap } = require('../../dist/mcp/utils.js');
        const builtin = [{ name: 'a' }, { name: 'b' }];
        const consumer = [{ name: 'c' }];

        const map = buildToolMap(builtin, consumer);
        assert.equal(map.size, 3, 'Should have 3 tools total');
        assert.ok(map.has('a'), 'Should have a');
        assert.ok(map.has('b'), 'Should have b');
        assert.ok(map.has('c'), 'Should have c');
      },
    },

    // --- Real tools verification ---

    {
      name: 'every built-in tool has a role assigned',
      async run() {
        const tools = require('../../dist/mcp/tools.js');

        const missing = tools.filter((t) => !t.role);
        assert.equal(missing.length, 0, `All tools should have roles, missing: ${missing.map((t) => t.name).join(', ')}`);
      },
    },

    {
      name: 'every built-in route tool path is the path as served, under /omega/',
      async run() {
        const tools = require('../../dist/mcp/tools.js');

        const stray = tools.filter((t) => !t.path.startsWith('/omega/'));
        assert.equal(stray.length, 0, `Every built-in path is /omega/<route>, stray: ${stray.map((t) => `${t.name}=${t.path}`).join(', ')}`);
      },
    },

    {
      name: 'role distribution matches expected counts',
      async run() {
        const tools = require('../../dist/mcp/tools.js');

        const admin = tools.filter((t) => t.role === 'admin');
        const user = tools.filter((t) => t.role === 'user');
        const pub = tools.filter((t) => t.role === 'public');

        assert.equal(admin.length, 24, `Should have 24 admin tools, got ${admin.length}`);
        assert.equal(user.length, 2, `Should have 2 user tools, got ${user.length}`);
        assert.equal(pub.length, 2, `Should have 2 public tools, got ${pub.length}`);
        assert.equal(admin.length + user.length + pub.length, tools.length, 'Every tool is in a known role bucket');
      },
    },
  ],
});
