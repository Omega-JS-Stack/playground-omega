/**
 * Test: Security primitives (wave-2 B6/B10) — pure functions, called directly.
 *
 * - safeCompare: constant-time secret comparison (admin key, webhook keys)
 * - loadProvider: provider-name confinement for dynamic require()
 * - loadTemplate: email-template-id confinement (colon-joined ids → nested folders)
 */
const path = require('path');
const safeCompare = require('../../dist/manager/helpers/safe-compare.js');
const loadProvider = require('../../dist/manager/libraries/load-provider.js');
const defineCases = require('../../dist/vendor/devkit/test/define-cases.js');
const { loadTemplate } = loadProvider;

const PROVIDERS_DIR = path.join(__dirname, '../../dist/manager/routes/payments/webhook/providers');
const TEMPLATES_DIR = path.join(__dirname, '../../dist/manager/routes/general/email/templates');

module.exports = defineCases({
  description: 'safeCompare + loadProvider security primitives',
  type: 'group',
  timeout: 10000,

  tests: [
    {
      name: 'safe-compare-equality',
      auth: 'none',

      async run({ assert }) {
        if (!((safeCompare('secret-key', 'secret-key')) === true)) { assert.fail('equal strings compare true'); }
        if (!((safeCompare('secret-key', 'secret-kez')) === false)) { assert.fail('different strings compare false'); }
        if (!((safeCompare('short', 'a-much-longer-value')) === false)) { assert.fail('length mismatch compares false'); }
      },
    },

    {
      name: 'safe-compare-rejects-empty-and-non-strings',
      auth: 'none',

      async run({ assert }) {
        // An unset OMEGA_ADMIN_KEY/OMEGA_WEBHOOK_KEY must never match anything
        if (!((safeCompare('', '')) === false)) { assert.fail('empty vs empty is false'); }
        if (!((safeCompare('x', '')) === false)) { assert.fail('value vs empty is false'); }
        if (!((safeCompare(undefined, 'x')) === false)) { assert.fail('undefined is false'); }
        if (!((safeCompare(null, null)) === false)) { assert.fail('null is false'); }
      },
    },

    {
      name: 'load-provider-allows-valid-names',
      auth: 'none',

      async run({ assert }) {
        const stripe = loadProvider(PROVIDERS_DIR, 'stripe');
        if (!(typeof stripe === 'object' || typeof stripe === 'function')) { assert.fail('stripe provider loads'); }
      },
    },

    {
      name: 'load-provider-rejects-traversal-names',
      auth: 'none',

      async run({ assert }) {
        const invalid = ['../post', '..', 'stripe/../../post', 'Stripe', 'a.b', '', null, 'a b'];

        for (const name of invalid) {
          let threw = false;
          try {
            loadProvider(PROVIDERS_DIR, name);
          } catch (e) {
            threw = true;
          }
          if (!threw) { assert.fail(`"${name}" must be rejected`); }
        }
      },
    },

    {
      name: 'load-template-allows-valid-ids',
      auth: 'none',

      async run({ assert }) {
        const nested = loadTemplate(TEMPLATES_DIR, 'general:download-app-link');
        if (!(typeof nested === 'function')) { assert.fail('nested template loads by colon-joined id'); }
      },
    },

    {
      name: 'load-template-rejects-traversal-ids',
      auth: 'none',

      async run({ assert }) {
        const invalid = ['..:..:..:etc:passwd', '../general', '..', 'general:../..', 'General:Download', 'a.b', '', null, 'a b:c'];

        for (const id of invalid) {
          let threw = false;
          try {
            loadTemplate(TEMPLATES_DIR, id);
          } catch (e) {
            threw = true;
          }
          if (!threw) { assert.fail(`"${id}" must be rejected`); }
        }
      },
    },
  ],
});
