/**
 * Test: environment detection + URL helpers
 * Covers the Manager's getEnvironment() SSOT, the derived is*() checks, the URL
 * builders (getApiUrl / getFunctionsUrl / getWebsiteUrl + parent variants), and the
 * ctx→Manager forwarding.
 *
 * Run: npx omega test backend:helpers/environment
 *
 * Contract (see docs/environment-detection.md):
 *   - getEnvironment() is the SINGLE SOURCE OF TRUTH — the only reader of the raw env
 *     vars (OMEGA_TEST_MODE / ENVIRONMENT / FUNCTIONS_EMULATOR / TERM_PROGRAM). Returns
 *     exactly ONE of 'development' | 'testing' | 'production' (testing wins).
 *   - isDevelopment()/isProduction()/isTesting() DERIVE from getEnvironment() — they
 *     never read raw signals, so they can NEVER disagree with it. Exactly one is true.
 *   - getApiUrl/getFunctionsUrl/getWebsiteUrl resolve LOCAL in dev OR testing, prod
 *     otherwise. The parent helpers ALWAYS return the live URL (no localhost).
 *   - The ctx forwards each method to its Manager (identical results).
 */

// The local port a getter must answer with: the RESOLVED one the CLI injected
// into this runner child (OMEGA_<NAME>_PORT, the #291 map), classic default
// when unset. Pinning the classic numbers here failed every bumped run — a
// second stack on 5001/5002 moves the whole map and the getters move with it
// ([#291](https://github.com/Omega-JS-Stack/omega/issues/291)). A getter that
// hardcodes its port still fails these: on a bumped run it answers the classic
// number while this reads the injected one.

const defineCases = require('../../dist/vendor/devkit/test/define-cases.js');
function localPort(name, classic) {
  return process.env[`OMEGA_${name}_PORT`] || classic;
}

// Run a thunk with the env-detection vars cleared, restoring them afterward. These are
// the only inputs getEnvironment() reads, so clearing them gives a clean slate per case.
function withEnv(overrides, fn) {
  const KEYS = ['OMEGA_TEST_MODE', 'ENVIRONMENT', 'FUNCTIONS_EMULATOR', 'TERM_PROGRAM'];
  const saved = {};
  for (const k of KEYS) saved[k] = process.env[k];
  try {
    for (const k of KEYS) delete process.env[k];
    for (const k of Object.keys(overrides)) process.env[k] = overrides[k];
    return fn();
  } finally {
    for (const k of KEYS) {
      if (saved[k] === undefined) delete process.env[k];
      else process.env[k] = saved[k];
    }
  }
}

module.exports = defineCases({
  description: 'Environment detection + URL helpers',
  type: 'group',

  tests: [
    // ─── getEnvironment() resolution + precedence ───

    {
      name: 'getEnvironment: testing wins over everything (OMEGA_TEST_MODE=true)',
      async run({ Manager, assert }) {
        withEnv({ OMEGA_TEST_MODE: 'true', ENVIRONMENT: 'production' }, () => {
          assert.equal(Manager.getEnvironment(), 'testing');
        });
      },
    },
    {
      name: 'getEnvironment: production when ENVIRONMENT=production (not testing)',
      async run({ Manager, assert }) {
        withEnv({ ENVIRONMENT: 'production' }, () => {
          assert.equal(Manager.getEnvironment(), 'production');
        });
      },
    },
    {
      name: 'getEnvironment: development when ENVIRONMENT=development',
      async run({ Manager, assert }) {
        withEnv({ ENVIRONMENT: 'development' }, () => {
          assert.equal(Manager.getEnvironment(), 'development');
        });
      },
    },
    {
      name: 'getEnvironment: development when FUNCTIONS_EMULATOR is set',
      async run({ Manager, assert }) {
        withEnv({ FUNCTIONS_EMULATOR: 'true' }, () => {
          assert.equal(Manager.getEnvironment(), 'development');
        });
      },
    },
    {
      name: 'getEnvironment: defaults to production with no signal (deployed function)',
      async run({ Manager, assert }) {
        withEnv({}, () => {
          assert.equal(Manager.getEnvironment(), 'production');
        });
      },
    },

    // ─── The KEY invariant: is*() derive from getEnvironment() and can NEVER disagree ───

    {
      name: 'invariant: is*() exactly matches getEnvironment() across every scenario',
      async run({ Manager, assert }) {
        const scenarios = [
          { env: { OMEGA_TEST_MODE: 'true', ENVIRONMENT: 'production' }, expect: 'testing' },
          { env: { ENVIRONMENT: 'production' },                     expect: 'production' },
          { env: { ENVIRONMENT: 'development' },                    expect: 'development' },
          { env: { FUNCTIONS_EMULATOR: 'true' },                    expect: 'development' },
          { env: {},                                                expect: 'production' },
        ];
        for (const s of scenarios) {
          withEnv(s.env, () => {
            const e = Manager.getEnvironment();
            assert.equal(e, s.expect, `getEnvironment for ${JSON.stringify(s.env)}`);
            // Each is*() must equal (getEnvironment() === its value) — no independent reads.
            assert.equal(Manager.isDevelopment(), e === 'development', `isDevelopment for ${e}`);
            assert.equal(Manager.isTesting(),     e === 'testing',     `isTesting for ${e}`);
            assert.equal(Manager.isProduction(),  e === 'production',  `isProduction for ${e}`);
          });
        }
      },
    },
    {
      name: 'invariant: exactly one of is*() is true in every scenario (mutually exclusive)',
      async run({ Manager, assert }) {
        const envs = [
          { OMEGA_TEST_MODE: 'true' },
          { ENVIRONMENT: 'production' },
          { ENVIRONMENT: 'development' },
          { FUNCTIONS_EMULATOR: 'true' },
          {},
        ];
        for (const env of envs) {
          withEnv(env, () => {
            const trueCount = [Manager.isDevelopment(), Manager.isTesting(), Manager.isProduction()]
              .filter(Boolean).length;
            assert.equal(trueCount, 1, `exactly one true for ${JSON.stringify(env)}`);
          });
        }
      },
    },
    {
      name: 'isProduction is a real positive check (NOT just !isDevelopment) — false in testing',
      async run({ Manager, assert }) {
        withEnv({ OMEGA_TEST_MODE: 'true' }, () => {
          assert.equal(Manager.isDevelopment(), false, 'isDevelopment false in testing');
          assert.equal(Manager.isProduction(),  false, 'isProduction false in testing');
          assert.equal(Manager.isTesting(),     true,  'isTesting true in testing');
        });
      },
    },

    // ─── ctx forwards to the Manager (identical results) ───

    {
      name: 'ctx forwards getEnvironment()/is*() to the Manager (identical)',
      async run({ Manager, ctx, assert }) {
        const cases = [
          { OMEGA_TEST_MODE: 'true' },
          { ENVIRONMENT: 'production' },
          { ENVIRONMENT: 'development' },
        ];
        for (const env of cases) {
          withEnv(env, () => {
            assert.equal(ctx.getEnvironment(), Manager.getEnvironment(), 'getEnvironment forward');
            assert.equal(ctx.isDevelopment(), Manager.isDevelopment(), 'isDevelopment forward');
            assert.equal(ctx.isTesting(),     Manager.isTesting(),     'isTesting forward');
            assert.equal(ctx.isProduction(),  Manager.isProduction(),  'isProduction forward');
          });
        }
      },
    },

    // ─── URL helpers: local in dev/testing, production otherwise ───

    {
      name: 'getApiUrl: localhost in development AND testing, prod otherwise',
      async run({ Manager, assert }) {
        const hosting = `http://localhost:${localPort('HOSTING', 5002)}`;
        withEnv({ FUNCTIONS_EMULATOR: 'true' }, () => {
          assert.equal(Manager.getApiUrl(), hosting, 'dev → localhost');
        });
        withEnv({ OMEGA_TEST_MODE: 'true' }, () => {
          assert.equal(Manager.getApiUrl(), hosting, 'testing → localhost');
        });
        withEnv({ ENVIRONMENT: 'production' }, () => {
          assert.match(Manager.getApiUrl(), /^https:\/\/api\./, 'prod → api.<domain>');
        });
      },
    },
    {
      name: 'getApiUrl: explicit env arg overrides current environment',
      async run({ Manager, assert }) {
        // Under the test harness we're in 'testing', but an explicit arg forces the mapping.
        assert.equal(Manager.getApiUrl('development'), `http://localhost:${localPort('HOSTING', 5002)}`, "arg 'development' → localhost");
        assert.match(Manager.getApiUrl('production'), /^https:\/\/api\./, "arg 'production' → prod");
      },
    },
    {
      name: 'getFunctionsUrl: localhost in development AND testing, cloudfunctions otherwise',
      async run({ Manager, assert }) {
        const functions = new RegExp(`^http://localhost:${localPort('FUNCTIONS', 5001)}/`);
        withEnv({ FUNCTIONS_EMULATOR: 'true' }, () => {
          assert.match(Manager.getFunctionsUrl(), functions, `dev → localhost:${localPort('FUNCTIONS', 5001)}`);
        });
        withEnv({ OMEGA_TEST_MODE: 'true' }, () => {
          assert.match(Manager.getFunctionsUrl(), functions, `testing → localhost:${localPort('FUNCTIONS', 5001)}`);
        });
        withEnv({ ENVIRONMENT: 'production' }, () => {
          assert.match(Manager.getFunctionsUrl(), /cloudfunctions\.net$/, 'prod → cloudfunctions.net');
        });
      },
    },
    {
      name: 'getWebsiteUrl: localhost:4000 in development AND testing, brand.url otherwise',
      async run({ Manager, assert }) {
        // The scheme follows the local https stack (cp177): OMEGA_HTTPS_PORT set
        // (this process runs behind the mkcert proxy) → the website dev server
        // shares the same mkcert default → https. Unset → both sides plain http.
        // Controlled explicitly in BOTH directions so ambient env can't skew it.
        const savedHttpsPort = process.env.OMEGA_HTTPS_PORT;
        const website = localPort('WEBSITE', 4000);
        try {
          delete process.env.OMEGA_HTTPS_PORT;
          withEnv({ FUNCTIONS_EMULATOR: 'true' }, () => {
            assert.equal(Manager.getWebsiteUrl(), `http://localhost:${website}`, `dev → localhost:${website}`);
          });
          withEnv({ OMEGA_TEST_MODE: 'true' }, () => {
            assert.equal(Manager.getWebsiteUrl(), `http://localhost:${website}`, `testing → localhost:${website}`);
          });

          process.env.OMEGA_HTTPS_PORT = '5002';
          withEnv({ FUNCTIONS_EMULATOR: 'true' }, () => {
            assert.equal(Manager.getWebsiteUrl(), `https://localhost:${website}`, 'dev behind the https proxy → https website');
          });

          withEnv({ ENVIRONMENT: 'production' }, () => {
            const url = Manager.getWebsiteUrl();
            assert.equal(url.includes('localhost'), false, 'prod → NOT localhost');
          });
        } finally {
          if (savedHttpsPort === undefined) delete process.env.OMEGA_HTTPS_PORT;
          else process.env.OMEGA_HTTPS_PORT = savedHttpsPort;
        }
      },
    },

    // ─── Parent helpers ALWAYS resolve live (never localhost), even in dev/testing ───

    {
      name: 'getParentApiUrl / getParentUrl never redirect to localhost (always live)',
      async run({ Manager, assert }) {
        // Even under the test harness ('testing'), the parent is a real remote server.
        const parentUrl = Manager.getParentUrl();
        const parentApi = Manager.getParentApiUrl();
        assert.equal((parentUrl || '').includes('localhost'), false, 'getParentUrl not localhost');
        assert.equal((parentApi || '').includes('localhost'), false, 'getParentApiUrl not localhost');
        // When set, the parent API URL carries the api. subdomain.
        if (parentApi) assert.match(parentApi, /^https:\/\/api\./, 'parent api uses api. subdomain');
      },
    },
  ],
});
