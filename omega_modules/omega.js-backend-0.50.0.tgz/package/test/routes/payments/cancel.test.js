/**
 * Test: POST /payments/cancel - Validation errors
 * Tests rejection cases before any provider call is made.
 * See test/events/payments/journey-payments-cancel-endpoint.js for the full end-to-end journey.
 */

const defineCases = require('../../../dist/vendor/devkit/test/define-cases.js');
module.exports = defineCases({
  description: 'Payment cancel endpoint: validation errors',
  type: 'group',
  timeout: 15000,

  tests: [
    {
      name: 'rejects-unauthenticated',
      async run({ http, assert }) {
        const response = await http.as('none').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 401, 'Should reject unauthenticated request');
      },
    },

    {
      name: 'rejects-missing-confirmed',
      async run({ http, assert }) {
        const response = await http.as('basic').post('backend-manager/payments/cancel', {
          reason: 'Too expensive',
        });

        assert.isError(response, 400, 'Should reject missing confirmed field');
      },
    },

    {
      name: 'rejects-basic-user',
      async run({ http, assert }) {
        const response = await http.as('basic').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 400, 'Should reject basic user with no paid subscription');
      },
    },

    {
      name: 'rejects-no-provider-or-resource-id',
      async run({ http, assert }) {
        // cancel-no-provider starts with payment.provider=null
        const response = await http.as('cancel-no-provider').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 400, 'Should reject when no provider or resourceId is set');
      },
    },

    {
      name: 'rejects-already-pending-cancellation',
      async run({ http, assert }) {
        // cancel-already-pending starts with cancellation.pending=true
        const response = await http.as('cancel-already-pending').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 400, 'Should reject when cancellation already pending');
      },
    },

    {
      name: 'rejects-subscription-younger-than-24-hours',
      async run({ http, assert }) {
        // cancel-too-young starts with startDate set to now (< 24 hours old)
        const response = await http.as('cancel-too-young').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 400, 'Should reject subscription younger than 24 hours');
      },
    },

    {
      name: 'rejects-unknown-provider',
      async run({ http, assert }) {
        // cancel-unknown-provider starts with provider='unknown-provider'
        const response = await http.as('cancel-unknown-provider').post('backend-manager/payments/cancel', {
          confirmed: true,
        });

        assert.isError(response, 400, 'Should reject unknown provider');
      },
    },

    {
      name: 'allows-suspended-subscription',
      async run({ http, assert, config, accounts, firestore, waitFor, skip }) {
        const uid = accounts['cancel-suspended'].uid;

        const response = await http.as('cancel-suspended').post('backend-manager/payments/cancel', {
          confirmed: true,
          reason: 'Subscription was suspended',
          skipGuards: true,
        });

        assert.isSuccess(response, 'Should allow cancelling a suspended subscription');
        assert.equal(response.data.success, true, 'Should return success: true');

        // Verify the subscription was reset to cancelled (via fallback or webhook)
        await waitFor(async () => {
          const userDoc = await firestore.get(`users/${uid}`);
          return userDoc?.subscription?.status === 'cancelled'
            || userDoc?.subscription?.cancellation?.pending === true;
        }, 15000, 500);
      },
    },

    {
      name: 'succeeds-with-test-provider',
      async run({ http, assert, config, accounts, firestore, waitFor, skip }) {
        const uid = accounts['route-cancel-success'].uid;
        const paidProduct = config.payment.products.find(p => p.id !== 'basic' && p.prices?.monthly);
        if (!paidProduct) {
          skip('No paid product with monthly price configured in this brand');
        }

        // Step 1: Create a test subscription intent to set up a proper paid subscription
        const intentResponse = await http.as('route-cancel-success').post('backend-manager/payments/intent', {
          provider: 'test',
          productId: paidProduct.id,
          frequency: 'monthly',
        });

        assert.isSuccess(intentResponse, 'Intent should succeed');

        // Wait for the auto-webhook to activate the subscription
        await waitFor(async () => {
          const userDoc = await firestore.get(`users/${uid}`);
          return userDoc?.subscription?.payment?.provider === 'test'
            && userDoc?.subscription?.payment?.resourceId
            && userDoc?.subscription?.status === 'active';
        }, 15000, 500);

        // Step 2: Call the cancel endpoint (skipGuards bypasses the 24-hour age guard)
        const cancelResponse = await http.as('route-cancel-success').post('backend-manager/payments/cancel', {
          confirmed: true,
          reason: 'Too expensive',
          skipGuards: true,
        });

        assert.isSuccess(cancelResponse, 'Cancel should succeed');
        assert.equal(cancelResponse.data.success, true, 'Should return success: true');

        // Step 3: Verify cancellation.pending was set via the webhook pipeline
        await waitFor(async () => {
          const userDoc = await firestore.get(`users/${uid}`);
          return userDoc?.subscription?.cancellation?.pending === true;
        }, 15000, 500);

        const userDoc = await firestore.get(`users/${uid}`);
        assert.equal(userDoc?.subscription?.cancellation?.pending, true, 'Cancellation should be pending');
      },
    },
  ],
});
