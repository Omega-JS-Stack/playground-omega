/**
 * Test: POST /marketing/campaign — Send a marketing campaign (Single Send)
 *
 * Normal mode: creates campaign doc in Firestore, verifies structure
 * Extended mode (TEST_EXTENDED_MODE=true): sends a real test campaign via SendGrid/Beehiiv
 *   targeting the test_admin segment (hello@itwcreativeworks.com only)
 */

const defineCases = require('../../../dist/vendor/devkit/test/define-cases.js');

module.exports = defineCases({
  description: 'Marketing campaign (POST create + send)',
  type: 'group',
  tests: [
    {
      name: 'send-test-campaign',
      auth: 'admin',
      timeout: 60000,
      skip: !process.env.TEST_EXTENDED_MODE
        ? 'TEST_EXTENDED_MODE not set (real provider send)'
        : false,

      async run({ http, assert, state }) {
        const response = await http.post('backend-manager/marketing/campaign', {
          name: '@omega.js/backend Test Campaign',
          subject: 'Test Marketing Email',
          template: 'card',
          data: {
            content: {
              title: 'Test Marketing Email',
              message: 'This is a **test marketing email** sent from the @omega.js/backend test suite.\n\nIf you received this, the SendGrid Single Send pipeline is working correctly.',
              button: { text: 'Visit Dashboard →', url: '{brand.url}' },
            },
          },
          test: true,
          sendAt: 'now',
        });

        assert.isSuccess(response, 'Campaign creation should succeed');
        assert.hasProperty(response, 'data.id', 'Response should contain campaign ID');
        assert.hasProperty(response, 'data.providers', 'Response should contain provider results');

        const providers = response.data.providers || {};

        console.log('Campaign results:', JSON.stringify(providers, null, 2));

        if (providers.campaigns) {
          state.sendgridId = providers.campaigns.id;

          assert.propertyEquals(
            response, 'data.providers.campaigns.success', true,
            `SendGrid should succeed. Error: ${providers.campaigns.error || 'none'}`,
          );
        }

        if (providers.newsletter) {
          assert.hasProperty(response, 'data.providers.newsletter', 'Should have Beehiiv result');
        }

        state.campaignId = response.data.id;
      },

      async cleanup({ state }) {
        if (state.campaignId) {
          console.log(`Campaign ID: ${state.campaignId}`);
        }
        if (state.sendgridId) {
          console.log(`SendGrid Single Send ID: ${state.sendgridId}`);
        }
      },
    },

    {
      name: 'create-future-campaign-is-pending',
      auth: 'admin',
      timeout: 30000,

      async run({ http, assert, firestore }) {
        // Future sendAt → campaign is saved as 'pending' for cron pickup, not sent immediately
        const futureDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

        const response = await http.post('backend-manager/marketing/campaign', {
          name: 'Future Campaign',
          subject: 'Future Subject',
          content: 'Future content',
          test: true,
          sendAt: futureDate,
        });

        assert.isSuccess(response, 'Future campaign creation should succeed');
        assert.hasProperty(response, 'data.id', 'Response should contain campaign ID');
        assert.propertyEquals(response, 'data.status', 'pending', 'Future campaign should be pending');

        const doc = await firestore.get(`marketing-campaigns/${response.data.id}`);
        assert.ok(doc, 'Campaign doc should exist in Firestore');
        assert.equal(doc.status, 'pending', 'Firestore doc status should be pending');
        assert.equal(doc.settings.name, 'Future Campaign', 'Name should match input');
        assert.propertyEquals(response, 'data.providers', null, 'Future campaign should not have provider results');
      },
    },

    {
      name: 'campaign-rejects-raw-content-html',
      auth: 'admin',
      timeout: 15000,

      async run({ http, assert }) {
        // The raw-HTML passthrough is internal-caller only — an admin (or the MCP
        // create_campaign tool it fronts) must not bypass the escaped lane (#90).
        const response = await http.post('backend-manager/marketing/campaign', {
          name: 'Raw HTML Campaign',
          subject: 'Should fail',
          test: true,
          data: { content: { html: '<img src=x onerror="alert(1)">' } },
        });

        assert.isError(response, 400, 'data.content.html should be rejected with a 400');
      },
    },

    {
      name: 'campaign-doc-cannot-carry-caller-content-html',
      auth: 'admin',
      timeout: 30000,

      async run({ http, assert, firestore }) {
        // The stored doc is what the cron sender reads later, and the marketing library
        // reads contentHtml / data.content.html AHEAD of the escaped renderer — so
        // neither may ever land in it from a caller. Two layers stop this: the schema
        // strips the undeclared top-level contentHtml, and the handler's
        // internalOnlyFieldFault() rejects data.content.html outright.
        const futureDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

        const response = await http.post('backend-manager/marketing/campaign', {
          name: 'Raw HTML Persistence Probe',
          subject: 'Probe',
          contentHtml: '<img src=x onerror=alert(1)>',
          test: true,
          sendAt: futureDate,
        });

        assert.isSuccess(response, 'A campaign carrying only the stripped field should still create');

        const doc = await firestore.get(`marketing-campaigns/${response.data.id}`);

        assert.ok(doc, 'Campaign doc should exist in Firestore');
        assert.equal(doc.settings.contentHtml, undefined, 'Caller-supplied contentHtml persisted into the stored campaign doc');
        assert.ok(!JSON.stringify(doc).includes('onerror'), 'Raw HTML payload persisted into the stored campaign doc');
      },
    },

    {
      name: 'campaign-requires-admin',
      auth: 'user',
      timeout: 15000,

      async run({ http, assert }) {
        const response = await http.post('backend-manager/marketing/campaign', {
          name: 'Unauthorized Campaign',
          subject: 'Should fail',
          content: 'Should fail',
        });

        assert.isError(response, 403, 'Non-admin should get 403');
      },
    },

    {
      name: 'campaign-requires-auth',
      auth: 'none',
      timeout: 15000,

      async run({ http, assert }) {
        const response = await http.post('backend-manager/marketing/campaign', {
          name: 'Unauthenticated Campaign',
          subject: 'Should fail',
          content: 'Should fail',
        });

        assert.isError(response, 401, 'Unauthenticated should get 401');
      },
    },
  ],
});
