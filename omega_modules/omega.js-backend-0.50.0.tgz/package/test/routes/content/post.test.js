/**
 * Test: GET /content/post
 * Tests the content fetch post endpoint
 * Fetches blog post content from GitHub
 * Requires GitHub API key and a resolvable source repo (repo.org + brand.id -> <brand.id>-omega)
 */

const defineCases = require('../../../dist/vendor/devkit/test/define-cases.js');
module.exports = defineCases({
  description: 'General fetch post from GitHub',
  type: 'group',
  tests: [
    // Test 1: Missing URL returns 400 error
    {
      name: 'missing-url-rejected',
      auth: 'none',
      timeout: 15000,

      async run({ http, assert }) {
        const response = await http.get('backend-manager/content/post', {});

        assert.isError(response, 400, 'Missing URL should return 400');
      },
    },

    // Test 2: Non-existent post returns 404
    // The route searches live GitHub (route 500s "not configured" without a token),
    // so this only runs when GH_TOKEN is set — matches the mailbox-key skip pattern.
    {
      name: 'nonexistent-post-returns-404',
      auth: 'none',
      timeout: 30000,
      skip: !process.env.GH_TOKEN ? 'GH_TOKEN not set (content/post searches live GitHub)' : false,

      async run({ http, assert }) {
        const response = await http.get('backend-manager/content/post', {
          url: 'https://example.com/blog/this-post-definitely-does-not-exist-12345',
        });

        assert.isError(response, 404, 'Non-existent post should return 404');
      },
    },

    // Test 3: Authenticated user fetching non-existent post returns 404
    {
      name: 'authenticated-nonexistent-returns-404',
      auth: 'basic',
      timeout: 30000,
      skip: !process.env.GH_TOKEN ? 'GH_TOKEN not set (content/post searches live GitHub)' : false,

      async run({ http, assert }) {
        const response = await http.get('backend-manager/content/post', {
          url: 'https://example.com/blog/nonexistent-test-post-12345',
        });

        assert.isError(response, 404, 'Non-existent post should return 404');
      },
    },
  ],
});
