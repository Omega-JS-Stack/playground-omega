/**
 * Appearance Test Page JavaScript
 */

// Libraries
import omega from '@omega.js/web/runtime';
import { createLogger } from '__main_assets__/js/libs/logger.js';

const logger = createLogger('test:appearance');

// The debug panel's refresh, handed over by initDebugPanel so the controls
// below can call it. A no-op until the panel exists.
let refreshDebugPanel = () => {};

// Module
export default () => {
  return new Promise(async function (resolve) {
    // Initialize when DOM is ready
    await omega.dom.ready();

    // Initialize debug panel
    initDebugPanel();

    // Initialize programmatic controls
    initControls();

    // Initialize event logging
    initEventLog();

    // Resolve after initialization
    return resolve();
  });
};

/**
 * Initialize debug panel with live values
 */
function initDebugPanel() {
  const $debugSaved = document.getElementById('debug-saved');
  const $debugResolved = document.getElementById('debug-resolved');
  const $debugAttr = document.getElementById('debug-attr');
  const $debugLocalStorage = document.getElementById('debug-localstorage');
  const $debugSystem = document.getElementById('debug-system');
  const $btnRefresh = document.getElementById('btn-refresh');

  // Update function
  function updateDebug() {
    const appearance = omega.appearance;

    // Saved preference via API
    const saved = appearance.get();
    $debugSaved.textContent = saved !== null ? `"${saved}"` : 'null (not set)';

    // Resolved theme via API
    const resolved = appearance.getResolved();
    $debugResolved.textContent = `"${resolved}"`;

    // Raw HTML attribute
    const attr = document.documentElement.getAttribute('data-bs-theme');
    $debugAttr.textContent = `"${attr}"`;

    // Raw localStorage value (stored under _manager.appearance.preference)
    let rawStorage = null;
    try {
      const managerData = localStorage.getItem('_manager');
      const parsedData = managerData ? JSON.parse(managerData) : null;
      rawStorage = parsedData?.appearance?.preference || null;
    } catch (e) {
      rawStorage = '(error reading)';
    }
    $debugLocalStorage.textContent = rawStorage !== null ? `"${rawStorage}"` : 'null';

    // System preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const systemPref = prefersDark ? 'dark' : 'light';
    $debugSystem.textContent = `"${systemPref}" (prefers-color-scheme: ${prefersDark ? 'dark' : 'light'})`;

    logger.log('Debug updated:', {
      saved,
      resolved,
      attr,
      rawStorage,
      systemPref,
    });
  }

  // Initial update
  updateDebug();

  // Refresh button
  $btnRefresh.addEventListener('click', updateDebug);

  // Auto-update when theme changes (observe attribute changes)
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.attributeName === 'data-bs-theme') {
        updateDebug();
      }
    });
  });
  observer.observe(document.documentElement, { attributes: true });

  // Also listen for system preference changes
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  mediaQuery.addEventListener('change', updateDebug);

  // The Clear control refreshes the panel by hand (clearing fires no attribute
  // change when the resolved theme does not move), so the panel hands its
  // refresh to the module rather than to window (#342).
  refreshDebugPanel = updateDebug;
}

/**
 * Initialize programmatic control buttons
 */
function initControls() {
  const appearance = omega.appearance;

  // Toggle button
  document.getElementById('btn-toggle').addEventListener('click', () => {
    logger.log('Toggle clicked');
    appearance.toggle();
  });

  // Cycle button
  document.getElementById('btn-cycle').addEventListener('click', () => {
    logger.log('Cycle clicked');
    appearance.cycle();
  });

  // Clear button
  document.getElementById('btn-clear').addEventListener('click', () => {
    logger.log('Clear clicked');
    appearance.clear();
    // Trigger debug update
    refreshDebugPanel();
  });

  // Quick set buttons
  document.getElementById('btn-set-light').addEventListener('click', () => {
    logger.log('set("light") clicked');
    appearance.set('light');
  });

  document.getElementById('btn-set-dark').addEventListener('click', () => {
    logger.log('set("dark") clicked');
    appearance.set('dark');
  });

  document.getElementById('btn-set-system').addEventListener('click', () => {
    logger.log('set("system") clicked');
    appearance.set('system');
  });
}

/**
 * Initialize event logging
 */
function initEventLog() {
  const $log = document.getElementById('event-log');
  const $clearBtn = document.getElementById('btn-clear-log');
  let logLines = [];

  function addLogEntry(message) {
    const timestamp = new Date().toLocaleTimeString();
    const entry = `[${timestamp}] ${message}`;
    logLines.push(entry);

    // Keep last 50 entries
    if (logLines.length > 50) {
      logLines = logLines.slice(-50);
    }

    $log.textContent = logLines.join('\n');
    $log.scrollTop = $log.scrollHeight;
  }

  // Clear log button
  $clearBtn.addEventListener('click', () => {
    logLines = [];
    $log.textContent = 'Log cleared...';
  });

  // Observe data-bs-theme changes
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.attributeName === 'data-bs-theme') {
        const oldValue = mutation.oldValue;
        const newValue = document.documentElement.getAttribute('data-bs-theme');
        addLogEntry(`Theme changed: "${oldValue}" -> "${newValue}"`);
      }
    });
  });
  observer.observe(document.documentElement, {
    attributes: true,
    attributeOldValue: true,
    attributeFilter: ['data-bs-theme'],
  });

  // Log system preference changes
  const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  mediaQuery.addEventListener('change', (event) => {
    const systemPref = event.matches ? 'dark' : 'light';
    addLogEntry(`System preference changed: "${systemPref}"`);
  });

  // Log click events on appearance controls
  document.addEventListener('click', (event) => {
    const $target = event.target.closest('[data-appearance-set]');
    if ($target) {
      const value = $target.getAttribute('data-appearance-set');
      addLogEntry(`User clicked: set("${value}")`);
    }
  });

  // Initial log entry
  addLogEntry('Appearance test page loaded');
  addLogEntry(`Initial theme: "${document.documentElement.getAttribute('data-bs-theme')}"`);
  addLogEntry(`Saved preference: ${omega.appearance.get() || '(none)'}`);
}
