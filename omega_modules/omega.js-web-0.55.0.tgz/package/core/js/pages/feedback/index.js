/**
 * Feedback Page JavaScript
 */

// Libraries
import { FormManager } from '@omega.js/client/modules/form-manager.js';
import omega from '@omega.js/web/runtime';
import { WAKEUP_ROUTE } from '@omega.js/client/modules/request.js';
import { event } from '__main_assets__/js/libs/analytics.js';

// Module
export default () => {
  return new Promise(async function (resolve) {
    // Warm the backend the moment the page loads: the only thing this page
    // does is POST `/omega/user/feedback`, so the visitor's first click is the
    // one that would pay for a cold function. Fire-and-forget and
    // unauthenticated — the backend answers a wakeup before it loads a route
    // ([#644](https://github.com/Omega-JS-Stack/omega/issues/644)).
    omega.request(WAKEUP_ROUTE, { wakeup: true });

    // Initialize when DOM is ready
    await omega.dom.ready();

    setupForm();
    setupRatingButtons();

    // Resolve after initialization
    return resolve();
  });
};

// Setup rating button selection
function setupRatingButtons() {
  const $buttons = document.querySelectorAll('.feedback-rating-btn');

  $buttons.forEach($btn => {
    $btn.addEventListener('click', () => {
      selectRating($btn.dataset.rating);
    });
  });

  // Sync visual state with hidden input (may have been pre-populated by FormManager query params)
  const $ratingInput = document.getElementById('feedback-rating-input');
  if ($ratingInput?.value) {
    selectRating($ratingInput.value);
  }
}

// Select a rating
function selectRating(ratingId) {
  const $buttons = document.querySelectorAll('.feedback-rating-btn');
  const $ratingInput = document.getElementById('feedback-rating-input');

  // Remove active state from all buttons
  $buttons.forEach($b => $b.classList.remove('active'));

  // Set active state on target button
  const $target = document.querySelector(`.feedback-rating-btn[data-rating="${ratingId}"]`);
  if (!$target) {
    return;
  }

  $target.classList.add('active');
  $ratingInput.value = ratingId;
}

// Setup form handling
function setupForm() {
  const formManager = new FormManager(omega, '#feedback-form', {
    allowResubmit: false,
    resetOnSuccess: false,
    autoReady: false,
    submittingText: 'Submitting...',
    submittedText: 'Thank you!',
  });

  // Custom validation: require a rating selection
  formManager.on('validation', ({ data, setError }) => {
    if (!data.rating) {
      setError('rating', 'Please select a rating before submitting.');
    }
  });

  formManager.on('submit', async ({ data }) => {
    trackFeedbackSubmit(data.rating);

    const response = await omega.request(`/omega/user/feedback`, {
      method: 'POST',
      timeout: 30000,
      body: {
        rating: data.rating,
        positive: data.positive || '',
        negative: data.negative || '',
        comments: data.comments || '',
      },
    });

    formManager.showSuccess('Thank you for your feedback! Your input helps us improve.');

    // Check if the backend wants us to prompt for a review
    const review = response?.review;
    if (!review?.promptReview || !review?.reviewURL) {
      return;
    }

    showReviewModal(review.reviewURL, data);
  });

  // Wait for auth state before enabling the form
  omega.auth.listen({ once: true }, () => {
    formManager.ready();
  });
}

// Show the review prompt modal
function showReviewModal(reviewURL, data) {
  const $link = document.getElementById('review-modal-link');
  if (!$link) {
    return;
  }

  // Ensure it's a full URL
  const fullURL = reviewURL.startsWith('http') ? reviewURL : `https://${reviewURL}`;
  $link.href = fullURL;

  // Extract site name for display
  try {
    const siteName = new URL(fullURL).hostname.replace('www.', '');
    $link.innerHTML = `<i class="fa-solid fa-arrow-up-right-from-square me-2"></i> Post your review on ${omega.utilities.escapeHTML(siteName)}`;
  } catch (e) {
    // Use default text
  }

  // Populate the copy-paste feedback textarea with positive feedback
  const $feedbackTextarea = document.getElementById('review-modal-feedback');
  if ($feedbackTextarea) {
    const positiveParts = [data.positive, data.comments].filter(v => v && v.trim());
    $feedbackTextarea.value = positiveParts.join('\n\n');
  }

  // Setup copy button
  const $copyBtn = document.getElementById('review-modal-copy');
  if ($copyBtn && $feedbackTextarea) {
    $copyBtn.addEventListener('click', () => {
      // The clipboard rejects on a real refusal since #726: confirm only what
      // was copied, and never leave the rejection unhandled.
      omega.utilities.clipboardCopy($feedbackTextarea.value)
        .then(() => {
          $copyBtn.innerHTML = `<i class="fa-solid fa-check me-1"></i> Copied!`;
          setTimeout(() => {
            $copyBtn.innerHTML = `<i class="fa-solid fa-copy me-1"></i> Copy`;
          }, 2000);
        })
        .catch((error) => console.error('Failed to copy the feedback text:', error));
    }, { once: false });
  }

  // Track review prompt shown
  trackReviewPromptShown(fullURL);

  // Show modal
  const $modalElement = document.getElementById('review-modal');
  if (!$modalElement) {
    return;
  }

  const modal = new bootstrap.Modal($modalElement);
  modal.show();

  // Track when user clicks the review link
  $link.addEventListener('click', () => {
    trackReviewClick(fullURL);
  }, { once: true });
}

// Tracking functions
function trackFeedbackSubmit(rating) {
  event('feedback_submit', {
    feedback_rating: rating,
  });
}

function trackReviewPromptShown(url) {
  event('review_prompt_show', {
    review_url: url,
  });
}

function trackReviewClick(url) {
  event('review_click', {
    review_url: url,
  });
}
