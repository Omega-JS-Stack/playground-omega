// A theme module: the host calls the default export with { omega, options }.
// __main_assets__ is a build alias that resolves to the framework's core assets
import bootstrap from '__main_assets__/themes/bootstrap/js/index.umd.js';
import { ready as domReady } from '@omega.js/client/modules/dom.js';

// Make Bootstrap available globally
window.bootstrap = bootstrap;

// Log that we've MADE IT
/* @dev-only:start */
{
  console.log('Classy theme loaded successfully (assets/themes/classy/_theme.js)');
}
/* @dev-only:end */

// Nav glassiness, marquees, reveals, count-ups, and rotators all ride the
// shared motion engine (core/js/core/motion.js), so no theme JS is needed.

// Import tooltip initialization (the shared core-layer helper, #99)
import initializeTooltips from '__main_assets__/js/libs/initialize-tooltips.js';
// Import hero demo form initialization
import initHeroDemoForm from './js/hero-demo-form.js';

// Initialize theme components when DOM is ready
export default async function ({ omega, options }) {
  await domReady();

  // Generic Bootstrap initializations
  initializeTooltips();

  // Initialize hero demo form if present
  initHeroDemoForm(omega);
}
